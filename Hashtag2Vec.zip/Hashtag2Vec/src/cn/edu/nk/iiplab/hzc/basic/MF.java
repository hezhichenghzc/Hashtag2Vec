/**
 * This project is developed by the Intelligent Information Processing Lab, Nankai University, Tianjin, China. (http://dm.nankai.edu.cn/)
 * It follows the GPLv3 license. Feel free to use it for non-commercial purpose and please cite our paper:
 * @inproceedings{Hashtag2Vec,
 *   author    = {Jie Liu and Zhicheng He and Yalou Huang},
 *   title     = {Hashtag2Vec: Learning Hashtag Representation with Relational Hierarchical Embedding Model},
 *   booktitle = {Proceedings of the Twenty-Seventh International Joint Conference on Artificial Intelligence, {IJCAI} 2018, July 13-19, 2018, Stockholm, Sweden.},
 *   pages     = {3456--3462},
 *   year      = {2018},
 *   doi       = {10.24963/ijcai.2018/480},
 *   }
 * Contact: jliu@nankai.edu.cn, hezhicheng@mail.nankai.edu.cn
 */
package cn.edu.nk.iiplab.hzc.basic;

import cn.edu.nk.iiplab.hzc.basic.matrix.DenseMatrix;
import cn.edu.nk.iiplab.hzc.basic.matrix.RowSparseMatrix;
import cn.edu.nk.iiplab.hzc.basic.thread.*;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.lang.reflect.Constructor;
import java.util.ArrayList;
import java.util.HashMap;

public class MF {
    public static double epsilon = 1e-16;
    private HashMap<String, Object> matrixPool;

    //For reusing
    public void initMatrixPool() {
        if(matrixPool == null){
            matrixPool = new HashMap<>();
        }else{
            matrixPool.clear();
        }
    }

    public Object getFromMatrixPool(String name) throws Exception{
        if(matrixPool == null || !matrixPool.containsKey(name)){
            return null;
        }else if(matrixPool.get(name) == null){
            throw new Exception("No entry with key name: " + name + " in matrix pool");
        }else{
            return matrixPool.get(name);
        }
    }

    public void putIntoMatrixPool(String name, Object M){
        if(matrixPool == null){
            initMatrixPool();
        }
        matrixPool.put(name, M);
    }

    public void deleteFromMatrixPool(String name){
        if(matrixPool != null && matrixPool.containsKey(name)){
            matrixPool.remove(name);
        }
    }

    public DenseMatrix reusableMatrixMultiply(String name, DenseMatrix L, DenseMatrix R) throws Exception {
        DenseMatrix Result = (DenseMatrix)getFromMatrixPool(name);
        if(Result == null){
            Result = matrixMultiply(L, R);
            putIntoMatrixPool(name, Result);
        }
        return Result;
    }

    public DenseMatrix reusableMatrixMultiply(String name, DenseMatrix L, RowSparseMatrix R) throws Exception {
        DenseMatrix Result = (DenseMatrix)getFromMatrixPool(name);
        if(Result == null){
            Result = matrixMultiply(L, R);
            putIntoMatrixPool(name, Result);
        }
        return Result;
    }
//
//    public DenseMatrix reusableMatrixMultiply(String name, RowSparseMatrix L, DenseMatrix R) throws Exception {
//        DenseMatrix Result = (DenseMatrix)getFromMatrixPool(name);
//        if(Result == null){
//            Result = matrixMultiply(L, R);
//            putIntoMatrixPool(name, Result);
//        }
//        return Result;
//    }
//
//    public DenseMatrix reusableMatrixHadamardMultiply(String name, DenseMatrix L, DenseMatrix R) throws Exception {
//        DenseMatrix Result = (DenseMatrix)getFromMatrixPool(name);
//        if(Result == null){
//            Result = matrixHadamardMultiply(L, R);
//            putIntoMatrixPool(name, Result);
//        }
//        return Result;
//    }
//
//    public DenseMatrix reusableMatrixHadamardMultiply(String name, DenseMatrix L, RowSparseMatrix R) throws Exception {
//        DenseMatrix Result = (DenseMatrix)getFromMatrixPool(name);
//        if(Result == null){
//            Result = matrixHadamardMultiply(L, R);
//            putIntoMatrixPool(name, Result);
//        }
//        return Result;
//    }
//
//    public RowSparseMatrix reusableMatrixHadamardMultiply(String name, RowSparseMatrix L, RowSparseMatrix R) throws Exception{
//        RowSparseMatrix Result = (RowSparseMatrix)getFromMatrixPool(name);
//        if(Result == null){
//            Result = matrixHadamardMultiply(L, R);
//            putIntoMatrixPool(name, Result);
//        }
//        return Result;
//    }
//
//    public RowSparseMatrix reusableMatrixWeightedMultiply(String name, DenseMatrix L, DenseMatrix R, RowSparseMatrix W) throws Exception{
//        RowSparseMatrix Result = (RowSparseMatrix)getFromMatrixPool(name);
//        if(Result == null){
//            Result = matrixWeightedMultiply(L, R, W);
//            putIntoMatrixPool(name, Result);
//        }
//        return Result;
//    }

    public static void multiThreadRun(String className, Object[] paramIn, Object[] paramOut) throws Exception {
        ArrayList<Thread> lstThread = new ArrayList<Thread>();
        for (int iThread = 0; iThread < MultiThread.iMaxThreads; iThread++) {
            Class classType = Class.forName(className);
            Constructor constructor = classType.getConstructor(int.class, Object[].class, Object[].class);
            final MultiThread m_i = (MultiThread)constructor.newInstance(iThread, paramIn, paramOut);
            Thread t_i = new Thread(new Runnable() {
                @Override
                public void run() {
                    try {
                        m_i.run();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            });
            lstThread.add(t_i);
            t_i.start();
        }
        for (Thread thread : lstThread) {
            thread.join();
        }
    }

    public DenseMatrix matrixAdd(DenseMatrix L, DenseMatrix R) throws Exception {
        if(L.iNumOfRow != R.iNumOfRow || L.iNumOfColumn != R.iNumOfColumn){
            throw new Exception("Matrix add, dimensions not matched!");
        }
        DenseMatrix Result = new DenseMatrix(L.iNumOfRow, L.iNumOfColumn, 0);
        multiThreadRun("cn.edu.nk.iiplab.hzc.basic.thread.MatrixAdd_MultiThread", new Object[]{L, R}, new Object[]{Result});
        return Result;
    }

    public DenseMatrix matrixSpliceHorizontal(DenseMatrix L, DenseMatrix R) throws Exception {
        if(L.iNumOfRow != R.iNumOfRow){
            throw new Exception("Matrix splice horizontal, dimensions not matched!");
        }
        DenseMatrix Result = new DenseMatrix(L.iNumOfRow, L.iNumOfColumn + R.iNumOfColumn, 0);
        multiThreadRun("cn.edu.nk.iiplab.hzc.basic.thread.MatrixSpliceHorizontal_MultiThread", new Object[]{L, R}, new Object[]{Result});
        return Result;
    }

    public DenseMatrix matrixSpliceVertical(DenseMatrix U, DenseMatrix D) throws Exception {
        if(U.iNumOfColumn != D.iNumOfColumn){
            throw new Exception("Matrix splice vertical, dimensions not matched!");
        }
        DenseMatrix Result = new DenseMatrix(U.iNumOfRow + D.iNumOfRow, U.iNumOfColumn, 0);
        multiThreadRun("cn.edu.nk.iiplab.hzc.basic.thread.MatrixSpliceVertical_MultiThread", new Object[]{U, D}, new Object[]{Result});
        return Result;
    }

    public DenseMatrix rowSpan(double[] row, int nRow) throws Exception {
        if(row.length <= 0 || nRow <= 0){
            throw new Exception("Row Span, wrong dimensions");
        }
        DenseMatrix Result = new DenseMatrix(nRow, row.length, 0);
        multiThreadRun("cn.edu.nk.iiplab.hzc.basic.thread.RowSpan_MultiThread", new Object[]{row}, new Object[]{Result});
        return Result;
    }

    public DenseMatrix columnSpan(double[] col, int nCol) throws Exception {
        if(col.length <= 0 || nCol <= 0){
            throw new Exception("Row Span, wrong dimensions");
        }
        DenseMatrix Result = new DenseMatrix(col.length, nCol, 0);
        multiThreadRun("cn.edu.nk.iiplab.hzc.basic.thread.ColumnSpan_MultiThread", new Object[]{col}, new Object[]{Result});
        return Result;
    }

    public DenseMatrix matrixMinus(DenseMatrix L, DenseMatrix R) throws Exception {
        if(L.iNumOfRow != R.iNumOfRow || L.iNumOfColumn != R.iNumOfColumn){
            throw new Exception("Matrix add, dimensions not matched!");
        }
        DenseMatrix Result = new DenseMatrix(L.iNumOfRow, L.iNumOfColumn, 0);
        multiThreadRun("cn.edu.nk.iiplab.hzc.basic.thread.MatrixMinus_MultiThread", new Object[]{L, R}, new Object[]{Result});
        return Result;
    }

    public DenseMatrix matrixMultiplyNumber(DenseMatrix L, Double d) throws Exception {
        DenseMatrix Result = new DenseMatrix(L.iNumOfRow, L.iNumOfColumn, 0);
        multiThreadRun("cn.edu.nk.iiplab.hzc.basic.thread.MatrixMultiplyNumber_MultiThread", new Object[]{L, d}, new Object[]{Result});
        return Result;
    }

    public static double[] matrixMultiplyVector(DenseMatrix M, double[] v) throws Exception {
        if(M.iNumOfColumn != v.length){
            throw new Exception("Matrix multiply vector, dimensions not matched!");
        }
        double[] r = new double[M.iNumOfRow];
        multiThreadRun("cn.edu.nk.iiplab.hzc.basic.thread.MatrixMultiplyVector_MultiThread", new Object[]{M, v}, new Object[]{r});
        return r;
    }

    public static double[] matrixMultiplyVector(RowSparseMatrix M, double[] v) throws Exception {
        if(M.iNumOfColumn != v.length){
            throw new Exception("Matrix multiply vector, dimensions not matched!");
        }
        double[] r = new double[M.iNumOfRow];
        multiThreadRun("cn.edu.nk.iiplab.hzc.basic.thread.RSMatrixMultiplyVector_MultiThread", new Object[]{M, v}, new Object[]{r});
        return r;
    }

    public DenseMatrix matrixMultiplyDiagonal(DenseMatrix L, double[] R) throws Exception {
        if(L.iNumOfColumn != R.length){
            throw new Exception("Matrix multiply diagonal matrix, dimensions not matched");
        }
        DenseMatrix Result = new DenseMatrix(L.iNumOfRow, L.iNumOfColumn, 0);
        multiThreadRun("cn.edu.nk.iiplab.hzc.basic.thread.MatrixMultiplyDiagonal_MultiThread", new Object[]{L, R}, new Object[]{Result});
        return Result;
    }

    public RowSparseMatrix matrixMultiplyDiagonal(RowSparseMatrix L, double[] R) throws Exception {
        if(L.iNumOfColumn != R.length){
            throw new Exception("Matrix multiply diagonal matrix, dimensions not matched");
        }
        RowSparseMatrix Result = new RowSparseMatrix(L.iNumOfRow, L.iNumOfColumn);
        multiThreadRun("cn.edu.nk.iiplab.hzc.basic.thread.RSMatrixMultiplyDiagonal_MultiThread", new Object[]{L, R}, new Object[]{Result});
        return Result;
    }

    public double[] matrixMultiplyToDiagonal(DenseMatrix L, DenseMatrix R) throws Exception {
        if(L.iNumOfColumn != R.iNumOfRow || L.iNumOfRow != R.iNumOfColumn){
            throw new Exception("Matrix multiply 's diagonal, dimensions not matched!");
        }
        double[] diagonal = new double[L.iNumOfRow];
        multiThreadRun("cn.edu.nk.iiplab.hzc.basic.thread.MatrixMultiplyToDiagonal_MultiThread", new Object[]{L, R}, new Object[]{diagonal});
        return diagonal;
    }

    public DenseMatrix matrixMultiply(DenseMatrix L, DenseMatrix R) throws Exception {
        if(L.iNumOfColumn != R.iNumOfRow){
            throw new Exception("Matrix multiply, dimensions not matched!");
        }
        DenseMatrix Result = new DenseMatrix(L.iNumOfRow, R.iNumOfColumn, 0);
        multiThreadRun("cn.edu.nk.iiplab.hzc.basic.thread.MatrixMultiply_MultiThread", new Object[]{L, R}, new Object[]{Result});
        return Result;
    }

    public DenseMatrix matrixMultiply(DenseMatrix L, RowSparseMatrix R) throws Exception {
        if(L.iNumOfColumn != R.iNumOfRow){
            throw new Exception("Matrix multiply RSMatrix, dimensions not matched!");
        }
        DenseMatrix Result = new DenseMatrix(L.iNumOfRow, R.iNumOfColumn, 0);
        multiThreadRun("cn.edu.nk.iiplab.hzc.basic.thread.MatrixMultiplyRSMatrix_MultiThread", new Object[]{L, R}, new Object[]{Result});
        return Result;
    }

    public DenseMatrix matrixMultiply(RowSparseMatrix L, DenseMatrix R) throws Exception {
        if(L.iNumOfColumn != R.iNumOfRow){
            throw new Exception("RSMatrix multiply Matrix, dimensions not matched!");
        }
        DenseMatrix Result = new DenseMatrix(L.iNumOfRow, R.iNumOfColumn, 0);
        multiThreadRun("cn.edu.nk.iiplab.hzc.basic.thread.RSMatrixMultiplyMatrix_MultiThread", new Object[]{L, R}, new Object[]{Result});
        return Result;
    }

    public DenseMatrix matrixMultiplyLtR(RowSparseMatrix L, RowSparseMatrix R) throws Exception {
        if(L.iNumOfRow != R.iNumOfRow){
            throw new Exception("RSMatrix^T multiply RSMatrix, dimensions not matched!");
        }
        DenseMatrix Result = new DenseMatrix(L.iNumOfColumn, R.iNumOfColumn, 0);
        multiThreadRun("cn.edu.nk.iiplab.hzc.basic.thread.RSMatrixTMultiplyRSMatrix_MultiThread", new Object[]{L, R}, new Object[]{Result});
        return Result;
    }

    public DenseMatrix matrixHadamardMultiply(DenseMatrix L, DenseMatrix R) throws Exception {
        if(L.iNumOfRow != R.iNumOfRow || L.iNumOfColumn != R.iNumOfColumn){
            throw new Exception("Matrix Hadamard multiply, dimensions not matched!");
        }
        DenseMatrix Result = new DenseMatrix(L.iNumOfRow, R.iNumOfColumn, 0);
        multiThreadRun("cn.edu.nk.iiplab.hzc.basic.thread.MatrixHadamardMultiply_MultiThread", new Object[]{L, R}, new Object[]{Result});
        return Result;
    }

    public DenseMatrix matrixHadamardMultiply(DenseMatrix L, RowSparseMatrix R) throws Exception {
        if(L.iNumOfRow != R.iNumOfRow || L.iNumOfColumn != R.iNumOfColumn){
            throw new Exception("Matrix Hadamard multiply, dimensions not matched!");
        }
        DenseMatrix Result = new DenseMatrix(L.iNumOfRow, R.iNumOfColumn, 0);
        multiThreadRun("cn.edu.nk.iiplab.hzc.basic.thread.MatrixHadamardMultiplyRSMatrix_MultiThread", new Object[]{L, R}, new Object[]{Result});
        return Result;
    }

    public RowSparseMatrix matrixHadamardMultiply(RowSparseMatrix L, RowSparseMatrix R) throws Exception {
        if(L.iNumOfRow != R.iNumOfRow || L.iNumOfColumn != R.iNumOfColumn){
            throw new Exception("Matrix Hadamard multiply, dimensions not matched!");
        }
        RowSparseMatrix Result = new RowSparseMatrix(L.iNumOfRow, R.iNumOfColumn);
        multiThreadRun("cn.edu.nk.iiplab.hzc.basic.thread.RSMatrixHadamardMultiplyRSMatrix_MultiThread", new Object[]{L, R}, new Object[]{Result});
        return Result;
    }

    public RowSparseMatrix matrixWeightedMultiply(DenseMatrix L, DenseMatrix R, RowSparseMatrix W) throws Exception {
        if(L.iNumOfColumn != R.iNumOfRow || L.iNumOfRow != W.iNumOfRow || W.iNumOfColumn != R.iNumOfColumn){
            throw new Exception("Matrix Weighted multiply, dimensions not matched!");
        }
        RowSparseMatrix Result = new RowSparseMatrix(L.iNumOfRow, R.iNumOfColumn);
        multiThreadRun("cn.edu.nk.iiplab.hzc.basic.thread.MatrixWeightedMultiply_MultiThread", new Object[]{L, R, W}, new Object[]{Result});
        return Result;
    }

    public RowSparseMatrix matrixNonlinearDfWeightedMultiply(DenseMatrix L, DenseMatrix R, RowSparseMatrix W) throws Exception {
        if(L.iNumOfColumn != R.iNumOfRow || L.iNumOfRow != W.iNumOfRow || W.iNumOfColumn != R.iNumOfColumn){
            throw new Exception("Matrix Nonlinear Weighted multiply, dimensions not matched!");
        }
        RowSparseMatrix Result = new RowSparseMatrix(L.iNumOfRow, R.iNumOfColumn);
        multiThreadRun("cn.edu.nk.iiplab.hzc.basic.thread.MatrixNonlinearDfWeightedMultiply_MultiThread", new Object[]{L, R, W}, new Object[]{Result});
        return Result;
    }

    public RowSparseMatrix matrixNonlinearFWeightedMultiply(DenseMatrix L, DenseMatrix R, RowSparseMatrix W) throws Exception {
        if(L.iNumOfColumn != R.iNumOfRow || L.iNumOfRow != W.iNumOfRow || W.iNumOfColumn != R.iNumOfColumn){
            throw new Exception("Matrix Nonlinear Weighted multiply, dimensions not matched!");
        }
        RowSparseMatrix Result = new RowSparseMatrix(L.iNumOfRow, R.iNumOfColumn);
        multiThreadRun("cn.edu.nk.iiplab.hzc.basic.thread.MatrixNonlinearFWeightedMultiply_MultiThread", new Object[]{L, R, W}, new Object[]{Result});
        return Result;
    }

    public RowSparseMatrix matrixNonlinearFDfWeightedMultiply(DenseMatrix L, DenseMatrix R, RowSparseMatrix W) throws Exception {
        if(L.iNumOfColumn != R.iNumOfRow || L.iNumOfRow != W.iNumOfRow || W.iNumOfColumn != R.iNumOfColumn){
            throw new Exception("Matrix F Df Nonlinear Weighted multiply, dimensions not matched!");
        }
        RowSparseMatrix fR = matrixNonlinearFWeightedMultiply(L, R, W);
        RowSparseMatrix Result = matrixNonlinearDfWeightedMultiply(L, R, fR);
        return Result;
    }

    public DenseMatrix matrixTripleNonlinearProduct(DenseMatrix L, DenseMatrix M, DenseMatrix R) throws Exception {
        if(L.iNumOfColumn != M.iNumOfColumn || M.iNumOfRow != R.iNumOfRow){
            throw new Exception("Matrix Triple Nonlinear Product, dimensions not matched!");
        }
        DenseMatrix Result = new DenseMatrix(L.iNumOfRow, R.iNumOfColumn, 0);
        multiThreadRun("cn.edu.nk.iiplab.hzc.basic.thread.MatrixTripleNonlinearProduct_MultiThread", new Object[]{L, M, R}, new Object[]{Result});
        return Result;
    }

    public RowSparseMatrix matrixDivideProduct(RowSparseMatrix M, DenseMatrix L, DenseMatrix R) throws Exception {
        if(L.iNumOfColumn != R.iNumOfRow || L.iNumOfRow != M.iNumOfRow || M.iNumOfColumn != R.iNumOfColumn){
            throw new Exception("Matrix divide Product, dimensions not matched!");
        }
        RowSparseMatrix Result = new RowSparseMatrix(L.iNumOfRow, R.iNumOfColumn);
        multiThreadRun("cn.edu.nk.iiplab.hzc.basic.thread.MatrixDivideProduct_MultiThread", new Object[]{M, L, R}, new Object[]{Result});
        return Result;
    }

    public double[] normalizedCutWeight(RowSparseMatrix X) throws Exception{
        Double[] weight = new Double[X.iNumOfColumn];
        for (int i = 0; i < weight.length; i++){
            weight[i] = new Double(0);
        }
        multiThreadRun("cn.edu.nk.iiplab.hzc.basic.thread.NormalizedCutWeight_MultiThread", new Object[]{X}, new Object[]{weight});
        double[] w = new double[X.iNumOfColumn];
        for (int i = 0; i < w.length; i++){
            w[i] = weight[i];
        }
        return w;
    }

    public double weightedEuclideanLoss(RowSparseMatrix W, RowSparseMatrix D, DenseMatrix L, DenseMatrix R) throws Exception {
        if(L.iNumOfColumn != R.iNumOfRow || L.iNumOfRow != W.iNumOfRow || W.iNumOfColumn != R.iNumOfColumn
                || W.iNumOfRow != D.iNumOfRow || W.iNumOfColumn != D.iNumOfColumn){
            throw new Exception("Weighted Euclidean loss, dimensions not matched!");
        }
        ArrayList<Double> loss = new ArrayList<>();
        multiThreadRun("cn.edu.nk.iiplab.hzc.basic.thread.WeightedEuclideanLoss_MultiThread", new Object[]{W, D, L, R}, new Object[]{loss});
        double l = 0;
        for (double d : loss){
            l += d;
        }
        return l;
    }

    public void multiplicativeUpdate(DenseMatrix Nmrt, DenseMatrix Dnmnt, DenseMatrix X) throws Exception {
        if(X.iNumOfRow != Nmrt.iNumOfRow || X.iNumOfColumn != Nmrt.iNumOfColumn){
            throw new Exception("Multiplicative Update, numerator dimensions not matched!");
        }
        if(X.iNumOfRow != Dnmnt.iNumOfRow || X.iNumOfColumn != Dnmnt.iNumOfColumn){
            throw new Exception("Multiplicative Update, denominator dimensions not matched!");
        }
        multiThreadRun("cn.edu.nk.iiplab.hzc.basic.thread.MultiplicativeUpdate_MultiThread", new Object[]{Nmrt, Dnmnt}, new Object[]{X});
    }

    public void multiplicativeUpdate(DenseMatrix Nmrt, DenseMatrix Dnmnt, ArrayList<Integer> topicList, DenseMatrix X) throws Exception {
        if(X.iNumOfRow != Nmrt.iNumOfRow || X.iNumOfColumn != Nmrt.iNumOfColumn){
            throw new Exception("Multiplicative Update, numerator dimensions not matched!");
        }
        if(X.iNumOfRow != Dnmnt.iNumOfRow || X.iNumOfColumn != Dnmnt.iNumOfColumn){
            throw new Exception("Multiplicative Update, denominator dimensions not matched!");
        }
        multiThreadRun("cn.edu.nk.iiplab.hzc.basic.thread.MultiplicativeUpdate_MultiThread", new Object[]{Nmrt, Dnmnt, topicList}, new Object[]{X});
    }

    public void gradientDescentUpdate(DenseMatrix Nmrt, DenseMatrix Dnmnt, double stepsize, DenseMatrix X) throws Exception {
        if(X.iNumOfRow != Nmrt.iNumOfRow || X.iNumOfColumn != Nmrt.iNumOfColumn){
            throw new Exception("Gradient Descent Update, numerator dimensions not matched!");
        }
        if(X.iNumOfRow != Dnmnt.iNumOfRow || X.iNumOfColumn != Dnmnt.iNumOfColumn){
            throw new Exception("Gradient Descent Update, denominator dimensions not matched!");
        }
        multiThreadRun("cn.edu.nk.iiplab.hzc.basic.thread.GradientDescentUpdate_MultiThread", new Object[]{Nmrt, Dnmnt, stepsize}, new Object[]{X});
    }

    public void positiveProject(DenseMatrix X) throws Exception {
        multiThreadRun("cn.edu.nk.iiplab.hzc.basic.thread.PositiveProject_MultiThread", new Object[]{}, new Object[]{X});
    }

    public double RootMeanSquareError(RowSparseMatrix X, DenseMatrix L, DenseMatrix R, double min, double max) throws Exception{
        if(L.iNumOfColumn != R.iNumOfColumn || L.iNumOfRow != X.iNumOfRow || X.iNumOfColumn != R.iNumOfRow){
            throw new Exception("Root Mean Square Error, dimensions not matched!");
        }
        double se = SquarePredictError(X, L, R, min, max);
        int n = X.nnz();
        return Math.sqrt(se / n);
    }

    public double RootMeanSquareError(RowSparseMatrix X, DenseMatrix L1, DenseMatrix R1, DenseMatrix L2, DenseMatrix R2, double lamada1, double lamada2, double min, double max) throws Exception{
        if(L1.iNumOfColumn != R1.iNumOfColumn || L1.iNumOfRow != X.iNumOfRow || X.iNumOfColumn != R1.iNumOfRow
                || L2.iNumOfColumn != R2.iNumOfColumn || L2.iNumOfRow != X.iNumOfRow || X.iNumOfColumn != R2.iNumOfRow){
            throw new Exception("Root Mean Square Error, dimensions not matched!");
        }
        double se = SquarePredictError(X, L1, R1, L2, R2, lamada1, lamada2, min, max);
        int n = X.nnz();
        return Math.sqrt(se / n);
    }

    public double RelativeMeanSquareError(RowSparseMatrix X, DenseMatrix L, DenseMatrix R) throws Exception{
        double se = SquarePredictError(X, L, R);
        double nm = X.norm(2);
        return se / nm / nm;
    }

    public double RelativeMeanSquareError(RowSparseMatrix X, DenseMatrix L, DenseMatrix M, DenseMatrix R) throws Exception{
        DenseMatrix LM = matrixMultiply(L, M);
        return RelativeMeanSquareError(X, LM, R);
    }

    public double SquarePredictError(RowSparseMatrix X, DenseMatrix L, DenseMatrix R) throws Exception{
        return SquarePredictError(X, L, R, 0.0, Double.MAX_VALUE);
    }

    public double SquarePredictError(RowSparseMatrix X, DenseMatrix L, DenseMatrix R, Double min, Double max) throws Exception{
        if(L.iNumOfColumn != R.iNumOfColumn || L.iNumOfRow != X.iNumOfRow || X.iNumOfColumn != R.iNumOfRow){
            throw new Exception("Square Predict Error, dimensions not matched!");
        }
        ArrayList<Double> list = new ArrayList<>();
        multiThreadRun("cn.edu.nk.iiplab.hzc.basic.thread.SquarePredictError_MultiThread", new Object[]{X, L, R, min, max}, new Object[]{list});
        double se = 0;
        for (double e : list) {
            se += e;
        }
        return se;
    }

    public double SquarePredictError(RowSparseMatrix X, DenseMatrix L1, DenseMatrix R1, DenseMatrix L2, DenseMatrix R2, Double lamada1, Double lamada2, Double min, Double max) throws Exception{
        if(L1.iNumOfColumn != R1.iNumOfColumn || L1.iNumOfRow != X.iNumOfRow || X.iNumOfColumn != R1.iNumOfRow
                || L2.iNumOfColumn != R2.iNumOfColumn || L2.iNumOfRow != X.iNumOfRow || X.iNumOfColumn != R2.iNumOfRow){
            throw new Exception("Square Predict Error, dimensions not matched!");
        }
        ArrayList<Double> list = new ArrayList<>();
        multiThreadRun("cn.edu.nk.iiplab.hzc.basic.thread.JointSquarePredictError_MultiThread", new Object[]{X, L1, R1, L2, R2, lamada1, lamada2, min, max}, new Object[]{list});
        double se = 0;
        for (double e : list) {
            se += e;
        }
        return se;
    }

    //Output methods
    public static void OutputMatrix(String fn, DenseMatrix M) throws Exception {
        BufferedWriter bw = new BufferedWriter(new FileWriter(fn));
        bw.write("NumberOfRows:" + M.iNumOfRow + ";NumberOfColumns:" + M.iNumOfColumn);
        bw.newLine();
        for (int iRow = 0; iRow < M.iNumOfRow; iRow++) {
            bw.write(iRow + "\t");
            for (int iColumn = 0; iColumn < M.iNumOfColumn; iColumn++) {
                if (M.get(iRow, iColumn) > 0){
                    bw.write(iColumn + ":" + M.get(iRow, iColumn) + " ");
                }
            }
            bw.newLine();
        }
        bw.flush();
        bw.close();
    }

    public static void OutputMatrix(String fn, RowSparseMatrix M) throws Exception {
        BufferedWriter bw = new BufferedWriter(new FileWriter(fn));
        bw.write(M.iNumOfRow + " " + M.iNumOfColumn);
        bw.newLine();
        for (int iRow = 0; iRow < M.iNumOfRow; iRow++) {
            bw.write(iRow + " " + M.getRowLength(iRow) + " ");
            for (int iColumn = 0; iColumn < M.getRowLength(iRow); iColumn++) {
                bw.write(M.getRow(iRow)[iColumn].key + ":" + M.getRow(iRow)[iColumn].value + " ");
            }
            bw.newLine();
        }
        bw.flush();
        bw.close();
    }

    public static void OutputMatrixSparse(String fn, DenseMatrix M, int idxStart) throws Exception {
        BufferedWriter bw = new BufferedWriter(new FileWriter(fn));
        for (int iRow = 0; iRow < M.iNumOfRow; iRow++) {
            for (int iColumn = 0; iColumn < M.iNumOfColumn; iColumn++) {
                if (M.get(iRow, iColumn) > 0){
                    bw.write((iRow + idxStart) + " " + (iColumn + idxStart) + " " + M.get(iRow, iColumn));
                    bw.newLine();
                }
            }
        }
        bw.flush();
        bw.close();
    }

    public static void OutputMatrixSparse(String fn, RowSparseMatrix M, int shift) throws Exception {
        BufferedWriter bw = new BufferedWriter(new FileWriter(fn));
        for (int iRow = 0; iRow < M.iNumOfRow; iRow++) {
            for (int iColumn = 0; iColumn < M.getRowLength(iRow); iColumn++) {
                bw.write((iRow + shift) + " " + (M.getRow(iRow)[iColumn].key + shift) + " " + M.getRow(iRow)[iColumn].value);
                bw.newLine();
            }
        }
        bw.flush();
        bw.close();
    }

    public static void OutputMatrixRaw(String fn, DenseMatrix M) throws Exception {
        OutputMatrixRaw(fn, M, " ");
    }

    public static void OutputMatrixRaw(String fn, DenseMatrix M, String separator) throws Exception {
        BufferedWriter bw = new BufferedWriter(new FileWriter(fn));
        for (int iRow = 0; iRow < M.iNumOfRow; iRow++) {
            for (int iColumn = 0; iColumn < M.iNumOfColumn; iColumn++) {
                bw.write(M.get(iRow, iColumn) + separator);
            }
            bw.newLine();
        }
        bw.flush();
        bw.close();
    }

    public static void OutputVector(String fn, double[] M) throws Exception {
        BufferedWriter bw = new BufferedWriter(new FileWriter(fn));
        bw.write("NumberOfElements:" + M.length);
        bw.newLine();
        for (int i = 0; i < M.length; i++) {
            bw.write(i + ":" + M[i] + " ");
            bw.newLine();
        }
        bw.flush();
        bw.close();
    }

    public static void OutputVectorRaw(String fn, double[] M) throws Exception {
        BufferedWriter bw = new BufferedWriter(new FileWriter(fn));
        for (int i = 0; i < M.length; i++) {
            bw.write(M[i] + "");
            bw.newLine();
        }
        bw.flush();
        bw.close();
    }
    public DenseMatrix matrixEWMultiply(DenseMatrix L, DenseMatrix R) throws Exception {
        if(L.iNumOfRow != R.iNumOfRow || L.iNumOfColumn != R.iNumOfColumn){
            throw new Exception("Matrix elment-wise multiply, dimensions not matched!");
        }
        DenseMatrix Result = new DenseMatrix(L.iNumOfRow, L.iNumOfColumn, 0);
        multiThreadRun("cn.edu.nk.iiplab.hzc.basic.thread.MatrixEWMultiply_MultiThread", new Object[]{L, R}, new Object[]{Result});
        return Result;
    }

    public DenseMatrix matrixSqrt(DenseMatrix L) throws Exception {
        if(L.iNumOfRow==0|| L.iNumOfColumn==0){
            throw new Exception("Matrix sqrt, empty matrix!");
        }
        DenseMatrix Result = new DenseMatrix(L.iNumOfRow, L.iNumOfColumn, 0);
        multiThreadRun("cn.edu.nk.iiplab.hzc.basic.thread.MatrixSqrt_MultiThread", new Object[]{L}, new Object[]{Result});
        return Result;
    }

    public DenseMatrix matrixNZero(DenseMatrix L,double p) throws Exception {
        if(L.iNumOfRow==0|| L.iNumOfColumn==0){
            throw new Exception("Matrix nzero, empty matrix!");
        }
        DenseMatrix Result = new DenseMatrix(L.iNumOfRow, L.iNumOfColumn, 0);
        multiThreadRun("cn.edu.nk.iiplab.hzc.basic.thread.MatrixNZero_MultiThread", new Object[]{L,p}, new Object[]{Result});
        return Result;
    }
    public DenseMatrix matrixDivide(DenseMatrix L, DenseMatrix R) throws Exception {
        if(L.iNumOfRow != R.iNumOfRow || L.iNumOfColumn != R.iNumOfColumn){
            throw new Exception("Matrix divide, dimensions not matched!");
        }
        DenseMatrix Result = new DenseMatrix(L.iNumOfRow, L.iNumOfColumn, 0);
        multiThreadRun("cn.edu.nk.iiplab.hzc.basic.thread.MatrixDivide_MultiThread", new Object[]{L, R}, new Object[]{Result});
        return Result;
    }

}
