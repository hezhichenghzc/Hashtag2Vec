/**
 * This project is developed by the Intelligent Information Processing Lab, Nankai University, Tianjin, China. (http://dm.nankai.edu.cn/)
 * It follows the GPLv3 license. Feel free to use it for non-commercial purpose and please cite our paper:
 * @inproceedings{Hashtag2Vec,
 *   author    = {Jie Liu and Zhicheng He and Yalou Huang},
 *   title     = {Hashtag2Vec: Learning Hashtag Representation with Relational Hierarchical Embedding Model},
 *   booktitle = {Proceedings of the Twenty-Seventh International Joint Conference on Artificial Intelligence, {IJCAI} 2018, July 13-19, 2018, Stockholm, Sweden.},
 *   pages     = {3456--3462},
 *   year      = {2018},
 *   doi       = {10.24963/ijcai.2018/480},
 *   }
 * Contact: jliu@nankai.edu.cn, hezhicheng@mail.nankai.edu.cn
 */
package cn.edu.nk.iiplab.hzc.basic.thread;

import cn.edu.nk.iiplab.hzc.basic.matrix.DenseMatrix;

public class MatrixAdd_MultiThread extends MultiThread {
    public DenseMatrix L;
    public DenseMatrix R;
    public DenseMatrix Result;

    public MatrixAdd_MultiThread(int iThread, Object[] paramIn, Object[] paramOut) {
        iThreadID = iThread;
        L = (DenseMatrix) paramIn[0];
        R = (DenseMatrix) paramIn[1];
        Result = (DenseMatrix) paramOut[0];
    }

    public void run() throws Exception {
        for (int iRow = 0; iRow < L.iNumOfRow; iRow++) {
            if (iRow % iMaxThreads != iThreadID)
                continue;
            for (int iCol = 0; iCol < L.iNumOfColumn; iCol++) {
                Result.set(iRow, iCol, L.get(iRow, iCol) + R.get(iRow, iCol));
            }
        }
    }
}
