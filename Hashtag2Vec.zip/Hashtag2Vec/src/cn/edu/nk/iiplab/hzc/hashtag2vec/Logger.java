/**
 * This project is developed by the Intelligent Information Processing Lab, Nankai University, Tianjin, China. (http://dm.nankai.edu.cn/)
 * It follows the GPLv3 license. Feel free to use it for non-commercial purpose and please cite our paper:
 * @inproceedings{Hashtag2Vec,
 *   author    = {Jie Liu and Zhicheng He and Yalou Huang},
 *   title     = {Hashtag2Vec: Learning Hashtag Representation with Relational Hierarchical Embedding Model},
 *   booktitle = {Proceedings of the Twenty-Seventh International Joint Conference on Artificial Intelligence, {IJCAI} 2018, July 13-19, 2018, Stockholm, Sweden.},
 *   pages     = {3456--3462},
 *   year      = {2018},
 *   doi       = {10.24963/ijcai.2018/480},
 *   }
 * Contact: jliu@nankai.edu.cn, hezhicheng@mail.nankai.edu.cn
 */
package cn.edu.nk.iiplab.hzc.hashtag2vec;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Logger {

    public String folder_path;
    public String test_time;

    public Logger(String data_path, boolean batch) {

        SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd-HH-mm-ss");
        test_time = df.format(new Date());
        String time_now = "";
        if (batch)
            time_now = "../Hashtag2Vector_logs/" + data_path + "/test_time_" + test_time + "_batch" + "/";
        else
            time_now = "../Hashtag2Vector_logs/" + data_path + "/test_time_" + test_time + "/";
        File folder = new File(time_now);
        if (folder.mkdirs()) {
            this.folder_path = time_now;
        } else {
            System.out.println("create folder failed.");
        }
    }

    public void write(String content) throws IOException {
        String file_path = folder_path + "log.txt";
        File f = new File(file_path);
        if (!f.exists()) {
            f.createNewFile();
        }
        BufferedWriter bw = new BufferedWriter(new FileWriter(folder_path + "log.txt", true));
        bw.append(content + "\n");
        bw.close();

    }

    public void print(String s) {
        System.out.println(s);
    }


}
