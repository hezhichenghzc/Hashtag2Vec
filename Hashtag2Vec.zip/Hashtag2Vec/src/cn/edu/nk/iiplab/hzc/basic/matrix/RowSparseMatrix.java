/**
 * This project is developed by the Intelligent Information Processing Lab, Nankai University, Tianjin, China. (http://dm.nankai.edu.cn/)
 * It follows the GPLv3 license. Feel free to use it for non-commercial purpose and please cite our paper:
 * @inproceedings{Hashtag2Vec,
 *   author    = {Jie Liu and Zhicheng He and Yalou Huang},
 *   title     = {Hashtag2Vec: Learning Hashtag Representation with Relational Hierarchical Embedding Model},
 *   booktitle = {Proceedings of the Twenty-Seventh International Joint Conference on Artificial Intelligence, {IJCAI} 2018, July 13-19, 2018, Stockholm, Sweden.},
 *   pages     = {3456--3462},
 *   year      = {2018},
 *   doi       = {10.24963/ijcai.2018/480},
 *   }
 * Contact: jliu@nankai.edu.cn, hezhicheng@mail.nankai.edu.cn
 */
package cn.edu.nk.iiplab.hzc.basic.matrix;

import cn.edu.nk.iiplab.hzc.basic.struct.KeyValuePair;
import cn.edu.nk.iiplab.hzc.basic.util.Functions;
import cn.edu.nk.iiplab.hzc.basic.util.StringSplitter;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Random;

public class RowSparseMatrix {
    public KeyValuePair[][] pData;
    public int iNumOfRow = 0;
    public int iNumOfColumn = 0;
    public java.util.ArrayList<String> rowIDList;

    public RowSparseMatrix() {}
    public RowSparseMatrix(int iNumOfRow, int iNumOfColumn) {
        this.iNumOfRow = iNumOfRow;
        this.iNumOfColumn = iNumOfColumn;
        pData = new KeyValuePair[iNumOfRow][];
    }
    /**
     * load matrix entries from file
     * @param path file path
     * @return succeed or not
     * @throws Exception if file reading fails
     */
    public boolean load(String path) throws Exception {
        BufferedReader br = new BufferedReader(new FileReader(path));
        String line = br.readLine();
        String[] toks = StringSplitter.RemoveEmptyEntries(StringSplitter.split(",:; \t", line));
        iNumOfRow = Integer.parseInt(toks[1]);
        iNumOfColumn = Integer.parseInt(toks[3]);
        System.out.println("Loading " + iNumOfColumn + " samples and " + iNumOfRow + " features from " + path);

        pData = new KeyValuePair[iNumOfRow][];
        rowIDList = new ArrayList<>();
        int cnt = -1;
        while ((line = br.readLine()) != null) {
            String[] tokens = StringSplitter.RemoveEmptyEntries(StringSplitter.split("\t ", line));
            int length = Integer.parseInt(tokens[1]);
            cnt++;
            pData[cnt] = new KeyValuePair[length];
            for (int i = 0; i < length; i++) {
                pData[cnt][i] = new KeyValuePair();
                String[] kv = tokens[i + 3].split(":");
                pData[cnt][i].key = Integer.parseInt(kv[0]);
                pData[cnt][i].value = Double.parseDouble(kv[1]);
            }
            rowIDList.add(tokens[0]);
        }
        br.close();
        System.out.println(iNumOfColumn + " samples and " + iNumOfRow + " features are loaded");
        return true;
    }
//  翟羽佳扩展
    public boolean loadMy(String path) throws Exception{
        BufferedReader br = new BufferedReader(new FileReader(path));
        String line = br.readLine();
        String[] temp=line.split(" ");
        iNumOfRow=Integer.parseInt(temp[0]);
        iNumOfColumn=Integer.parseInt(temp[1]);
        pData = new KeyValuePair[iNumOfRow][];
        rowIDList = new ArrayList<>();
        while((line=br.readLine())!=null){
        	String[] temps=line.split(" ");
        	int row= Integer.parseInt(temps[0]);
        	int length=Integer.parseInt(temps[1]);
        	pData[row]=new KeyValuePair[length];
        	for(int i=2;i<temps.length;i++){
        		pData[row][i-2] = new KeyValuePair();
        		String[] temps1=temps[i].split(":");
        		int column=Integer.parseInt(temps1[0]);
        		double value=Double.parseDouble(temps1[1]);
                pData[row][i-2].key = column;
                pData[row][i-2].value = value;
        	}
            rowIDList.add(temps[0]);
        }
        br.close();
        return true;
        
    }

    public void save(String path) throws Exception{
        BufferedWriter bw = new BufferedWriter(new FileWriter(path));
        String dimension=iNumOfRow+" "+iNumOfColumn+"\n";
        bw.write(dimension);
        for(int i=0;i<pData.length;i++){
            bw.write(i+" "+pData[i].length+" ");
            for(int j=0;j<pData[i].length;j++){
                if(j<pData[i].length-1){
                    bw.write(pData[i][j].key+":"+pData[i][j].value+" ");
                }else{
                    bw.write(pData[i][j].key+":"+pData[i][j].value);
                }
            }
            bw.write("\n");
        }
        bw.close();
    }

    public DenseMatrix toDenseMatrix() throws Exception{
        DenseMatrix Result = new DenseMatrix(iNumOfRow, iNumOfColumn, 0);
        for (int iRow = 0; iRow < iNumOfRow; iRow++){
            for(KeyValuePair kv : pData[iRow]){
                Result.set(iRow, kv.key, kv.value);
            }
        }
        return Result;
    }
    public double[] normalizeByRow(double order) throws Exception{
        double[] norm = new double[iNumOfRow];
        for(int iRow = 0; iRow < iNumOfRow; iRow++){
            norm[iRow] = Functions.norm(pData[iRow], order);
            for(int iCol = 0; iCol < getRowLength(iRow); iCol++){
                this.pData[iRow][iCol].value= this.pData[iRow][iCol].value / Math.max(norm[iRow], Functions.epsilon);
            }
        }
        return norm;
    }


    public void show(){
    	if(pData==null){
    		System.out.println("Not initialized yet!");
    	}
    	System.out.println("Row: "+iNumOfRow+" Column: "+iNumOfColumn);
    	for(int i=0;i<pData.length;i++){
    		
    		KeyValuePair[] rowcontent=pData[i];
    		System.out.print(i+" "+rowcontent.length+" ");
    		for(int j=0;j<rowcontent.length;j++){
    			System.out.print(rowcontent[j].key+":"+rowcontent[j].value+" ");
    		}
    		System.out.print("\n");
    	}
    }

    public double sum(){
        if(pData==null){
            System.out.println("Not initialized yet!");
        }
        double sum=0;
        for(int i=0;i<pData.length;i++){
            KeyValuePair[] rowcontent=pData[i];
            for(int j=0;j<rowcontent.length;j++){
                sum+=rowcontent[j].value;
            }
        }
        return sum;
    }

    public double getSumRow(int i){
        if(pData==null){
            System.out.println("Not initialized yet!");
        }
        double sum=0;
        KeyValuePair[] rowcontent=pData[i];
        for(int j=0;j<rowcontent.length;j++){
            sum+=rowcontent[j].value;
        }
        return sum;
    }
    
    public double get(int row, int col) throws Exception{
        if (row >= iNumOfRow || col >= iNumOfColumn || pData == null) {
            throw new Exception("out of index bound");
        }
        for(int i = 0; i < pData[row].length; i++){
            if(pData[row][i].key == col){
                return pData[row][i].value;
            }
        }
        return 0;
    }

    /**
     * get method for matrix row
     * @param row row number
     * @return matrix row
     */
    public KeyValuePair[] getRow(int row) throws Exception{
        if (row >= iNumOfRow || pData == null) {
            throw new Exception("out of index bound");
        }
        return pData[row];
    }
    public void setRow(int iRow, KeyValuePair[] row) throws Exception{
        if (iRow >= iNumOfRow || pData == null) {
            throw new Exception("out of index bound");
        }
        pData[iRow] = row;
    }
    public int getRowLength(int row) throws Exception{
        if (row >= iNumOfRow || pData == null) {
            throw new Exception("out of index bound");
        }
        return pData[row].length;
    }
    public int nnz() throws Exception{
        if(pData == null){
            return 0;
        }
        int n = 0;
        for (int iRow = 0; iRow < iNumOfRow; iRow++){
            if(pData[iRow] != null){
                n += pData[iRow].length;
            }
        }
        return n;
    }
    public double norm(double order) throws Exception{
        double nm = 0;
        for (int iRow = 0; iRow < iNumOfRow; iRow++){
            nm += Math.pow(Functions.norm(pData[iRow], order), order);
        }
        return Math.pow(nm, 1 / order);
    }
    public String getRowID(int row) throws Exception{
        if (row >= iNumOfRow || pData == null) {
            throw new Exception("out of index bound");
        }
        return rowIDList.get(row);
    }
    public double[] getRowSums() throws Exception{
        if (pData == null) {
            throw new Exception("Empty matrix");
        }
        double[] r = new double[iNumOfRow];
        for (int iRow = 0; iRow < iNumOfRow; iRow++){
            for (KeyValuePair kv : pData[iRow]){
                r[iRow] += kv.value;
            }
        }
        return r;
    }
    public double getRowSum(int row) throws Exception{
        if (row >= iNumOfRow || pData == null) {
            throw new Exception("out of index bound");
        }
        double r = 0;
        for (KeyValuePair kv : pData[row]){
            r += kv.value;
        }
        return r;
    }

    public RowSparseMatrix binaryWeight() throws Exception{
        RowSparseMatrix Result = new RowSparseMatrix(this.iNumOfRow, this.iNumOfColumn);
        Result.rowIDList = new ArrayList<>(this.rowIDList);
        for (int iRow = 0; iRow < this.iNumOfRow; iRow++){
            Result.pData[iRow] = new KeyValuePair[this.pData[iRow].length];
            for(int iCol = 0; iCol < this.pData[iRow].length; iCol++){
                Result.pData[iRow][iCol] = new KeyValuePair(this.pData[iRow][iCol].key, 1);
            }
        }
        return Result;
    }

    public RowSparseMatrix binaryWeight(int iNumOfNeg) throws Exception{
        RowSparseMatrix Result = new RowSparseMatrix(this.iNumOfRow, this.iNumOfColumn);
        Result.rowIDList = new ArrayList<>(this.rowIDList);
        for (int iRow = 0; iRow < this.iNumOfRow; iRow++){
            Result.pData[iRow] = new KeyValuePair[this.pData[iRow].length + iNumOfNeg];
            HashSet<Integer> posSet = new HashSet<>();
            int iCol = 0;
            for(; iCol < this.pData[iRow].length; iCol++){
                Result.pData[iRow][iCol] = new KeyValuePair(this.pData[iRow][iCol].key, 1);
                posSet.add(this.pData[iRow][iCol].key);
            }
            Random random = new Random(System.currentTimeMillis());
            while (posSet.size() < this.pData[iRow].length + iNumOfNeg) {
                int n = random.nextInt(this.iNumOfColumn);
                if (!posSet.contains(n)){
                    Result.pData[iRow][iCol] = new KeyValuePair(n, 1);
                    iCol++;
                    posSet.add(n);
                }
            }
        }
        return Result;
    }
}
