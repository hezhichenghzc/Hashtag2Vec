/**
 * This project is developed by the Intelligent Information Processing Lab, Nankai University, Tianjin, China. (http://dm.nankai.edu.cn/)
 * It follows the GPLv3 license. Feel free to use it for non-commercial purpose and please cite our paper:
 * @inproceedings{Hashtag2Vec,
 *   author    = {Jie Liu and Zhicheng He and Yalou Huang},
 *   title     = {Hashtag2Vec: Learning Hashtag Representation with Relational Hierarchical Embedding Model},
 *   booktitle = {Proceedings of the Twenty-Seventh International Joint Conference on Artificial Intelligence, {IJCAI} 2018, July 13-19, 2018, Stockholm, Sweden.},
 *   pages     = {3456--3462},
 *   year      = {2018},
 *   doi       = {10.24963/ijcai.2018/480},
 *   }
 * Contact: jliu@nankai.edu.cn, hezhicheng@mail.nankai.edu.cn
 */
package cn.edu.nk.iiplab.hzc.basic.struct;

import java.util.Comparator;

public class KVPComparatorAsc implements Comparator {

    @Override
    public int compare(Object o1, Object o2) {
        KeyValuePair kv1 = (KeyValuePair)o1;
        KeyValuePair kv2 = (KeyValuePair)o2;
        if(kv1.value < kv2.value){
            return -1;
        }else if(kv1.value > kv2.value){
            return 1;
        }else if(kv1.value == kv2.value){
            return 0;
        }
        return 0;
    }
}
