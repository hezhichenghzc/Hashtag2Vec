/**
 * This project is developed by the Intelligent Information Processing Lab, Nankai University, Tianjin, China. (http://dm.nankai.edu.cn/)
 * It follows the GPLv3 license. Feel free to use it for non-commercial purpose and please cite our paper:
 * @inproceedings{Hashtag2Vec,
 *   author    = {Jie Liu and Zhicheng He and Yalou Huang},
 *   title     = {Hashtag2Vec: Learning Hashtag Representation with Relational Hierarchical Embedding Model},
 *   booktitle = {Proceedings of the Twenty-Seventh International Joint Conference on Artificial Intelligence, {IJCAI} 2018, July 13-19, 2018, Stockholm, Sweden.},
 *   pages     = {3456--3462},
 *   year      = {2018},
 *   doi       = {10.24963/ijcai.2018/480},
 *   }
 * Contact: jliu@nankai.edu.cn, hezhicheng@mail.nankai.edu.cn
 */
package cn.edu.nk.iiplab.hzc.basic.util;

import cn.edu.nk.iiplab.hzc.basic.matrix.DenseMatrix;
import cn.edu.nk.iiplab.hzc.basic.matrix.RowSparseMatrix;
import cn.edu.nk.iiplab.hzc.basic.struct.KeyValuePair;

import java.util.ArrayList;

public class Functions {
    public static double epsilon = 1e-16;

    //Scalar functions

    //f function
    public static double f(double d, String type) {
        if (type.equalsIgnoreCase("logistic")) {
            return logistic(d);
        } else if (type.equalsIgnoreCase("tanh")) {
            return Math.tanh(d);
        } else if (type.equalsIgnoreCase("softsign")) {
            return softsign(d);
        } else {
            return f(d, "logistic");
        }
    }

    public static double f(double d, double max, String type) {
        if (type.equalsIgnoreCase("logistic")) {
            return (logistic(d) - logistic(0)) / (logistic(max) - logistic(0));
        } else if (type.equalsIgnoreCase("tanh")) {
            return (Math.tanh(d) - Math.tanh(0)) / (Math.tanh(max) - Math.tanh(0));
        } else if (type.equalsIgnoreCase("softsign")) {
            return (softsign(d) - softsign(0)) / (softsign(max) - softsign(0));
        } else {
            return f(d, max, "logistic");
        }
    }

    public static double df(double d, String type) {
        if (type.equalsIgnoreCase("logistic")) {
            return logistic(d) * (1.0 - logistic(d));
        }else if (type.equalsIgnoreCase("tanh")) {
            return 1.0 - Math.tanh(d) * Math.tanh(d);
        } else if (type.equalsIgnoreCase("softsign")) {
            return 1.0 / Math.pow(1.0 + Math.abs(d), 2);
        } else {
            return df(d, "logistic");
        }
    }

    public static double df(double d, double max, String type) {
        if (type.equalsIgnoreCase("logistic")) {
            return logistic(d) * (1.0 - logistic(d)) / (logistic(max) - logistic(0));
        }else if (type.equalsIgnoreCase("tanh")) {
            return (1.0 - Math.tanh(d) * Math.tanh(d)) / (Math.tanh(max) - Math.tanh(0));
        } else if (type.equalsIgnoreCase("softsign")) {
            return 1.0 / Math.pow(1.0 + Math.abs(d), 2) / (softsign(max) - softsign(0));
        } else {
            return df(d, max, "logistic");
        }
    }

    public static double logistic(double d) {
        return 1.0 / (1.0 + Math.exp(-d));
    }

    public static double softsign(double d) {
        return d / (1.0 + Math.abs(d));
    }

    public static double g(double[] v1, double[] v2, String type) throws Exception{
        if (type.equalsIgnoreCase("l1")) {
            return norm(vecMinus(v1, v2), 1);
        } else if (type.equalsIgnoreCase("l2")) {
            return norm(vecMinus(v1, v2), 2);
        } else if (type.equalsIgnoreCase("arccos")) {
            double cos = cosine(v1, v2);
            if (cos > 1.0) {
                cos = 0.99;
            } else if (cos < -1.0) {
                cos = -0.99;
            }
            return Math.acos(cos);
        } else if (type.equalsIgnoreCase("1/cos")) {
            double cos = cosine(v1, v2);
            return 1.0 / cos;
        } else if (type.equalsIgnoreCase("1/cos-1")) {
            double cos = cosine(v1, v2);
            return 1.0 / cos - 1.0;
        }else if (type.equalsIgnoreCase("1-cos")) {
            double cos = cosine(v1, v2);
            return 1.0 - cos;
        }else if (type.equalsIgnoreCase("cos")) {
            return cosine(v1, v2);
        }else {
            return g(v1, v2, "l2");
        }
    }

    public static double g(double[] v, String type) throws Exception{
        if (type.equalsIgnoreCase("entropy")) {
            return entropy(v);
        }else {
            return 0.0;
        }
    }

    //derivative of g(v1, v2, type) to v1[i]
    public static double dg(int i, double[] v1, double[] v2, String type) throws Exception {
        if (type.equalsIgnoreCase("l1")) {
            return Math.signum(v1[i] - v2[i]);
        } else if (type.equalsIgnoreCase("l2")) {
            return 2.0 * v1[i] - 2.0 * v2[i];
        } else if (type.equalsIgnoreCase("arccos")) {
            double cos = cosine(v1, v2);
            if (cos >= 1.0) {
                cos = 0.99;
            } else if (cos <= -1.0) {
                cos = -0.99;
            }
            return darccos(cos) * dCosAngle(i, v1, v2);
        } else if (type.equalsIgnoreCase("1/cos")) {
            double cos = cosine(v1, v2);
            return -dCosAngle(i, v1, v2) / cos / cos;
        } else if (type.equalsIgnoreCase("1/cos-1")) {
            double cos = cosine(v1, v2);
            return -dCosAngle(i, v1, v2) / cos / cos;
        }else if (type.equalsIgnoreCase("cos")) {
            return dCosAngle(i, v1, v2);
        }else if (type.equalsIgnoreCase("1-cos")) {
            return -dCosAngle(i, v1, v2);
        }else {
            return dg(i, v1, v2, "l2");
        }
    }

    //derivative of g(v1, v2, type) to v1
    public static double[] dg(double[] v1, double[] v2, String type) throws Exception {
        if (type.equalsIgnoreCase("cos")) {
            return dCosAngle(v1, v2);
        }else {
            return new double[v1.length];
        }
    }

    public static double dg(int i, double[] v, String type) throws Exception {
        if (type.equalsIgnoreCase("entropy")) {
            double nm = norm(v, 1.0);
            double h = entropy(v);
            if (v[i] > 0){
                h += log(v[i] / nm);
            }
            return -h / nm;
        }else {
            return 0;
        }
    }

    public static double[] dg(double[] v, String type) throws Exception {
        if (type.equalsIgnoreCase("entropy")) {
            double nm = norm(v, 1);
            double h = entropy(v);
            double[] grad = new double[v.length];
            for (int i = 0; i < grad.length; i++){
                if (v[i] > 0){
                    grad[i] = -(log(v[i] / nm) + h) / nm;
                }
            }
            return grad;
        }else {
            return new double[v.length];
        }
    }

    public static double entropy(double[] v) throws Exception{
        double nm = norm(v, 1);
        double h = 0;
        for (double d : v){
            d = d / nm;
            if (d > 0){
                h += d * log(d);
            }
        }
        return -h;
    }

    public static double log(double d) {
        double l = Math.log(d) / Math.log(2.0);
        if (Double.isNaN(l)){
            l = 0.0;
        }
        return l;
    }

    //(arccosx)'=-1/(1-x^2)^1/2
    private static double darccos(double d) throws Exception {
        if (d > 1 || d < -1) {
            throw new Exception("Input cosine value out of bound!");
        }
        return -1.0 / Math.pow(1 - d * d, 0.5);
    }

    //d(v1*v2/|v1|/|v2|)/d(v1[i])
    private static double dCosAngle(int i, double[] v1, double[] v2) throws Exception{
        double nm1 = norm(v1, 2);
        double nm2 = norm(v2, 2);
        double prod = vecMultiply(v1, v2);

        return (v2[i] * nm1 - v1[i] * prod) / nm2 / Math.pow(nm1, 1.5);
    }

    //d(v1*v2/|v1|/|v2|)/d(v1)
    private static double[] dCosAngle(double[] v1, double[] v2) throws Exception{
        double nm1 = norm(v1, 2);
        double nm2 = norm(v2, 2);
        double prod = vecMultiply(v1, v2);

        double[] grad = new double[v1.length];
        for (int i = 0; i < grad.length; i++){
            grad[i] = (v2[i] * nm1 - v1[i] * prod) / nm2 / Math.pow(nm1, 1.5);
        }
        return grad;
    }

    public static double min(double[] d) {
        double m = d[0];
        for (int i = 1; i < d.length; i++){
            m = Math.min(m, d[i]);
        }
        return m;
    }

    public static double tfidf(double count, double totalCount, double numDoc, double numContained){
        return  tf(count, totalCount) * idf(numDoc, numContained);
    }

    private static double tf(double count, double totalCount){
        return count / totalCount;
    }

    private static double idf(double numDoc, double numContained){
        return log(numDoc / (numContained + 1.0));
    }

    //Vector functions
    public static double[] vecAdd(double[] d1, double[] d2) throws Exception{
        if(d1.length <= 0 || d2.length <= 0){
            throw new Exception("Vector add, empty vector not allowed!");
        }else if (d1.length != d2.length){
            throw new Exception("Vector add, dimension not matched!");
        }
        double[] d = new double[d1.length];
        for (int i = 0; i < d.length; i++) {
            d[i] = d1[i] + d2[i];
        }
        return d;
    }

    public static double[] vecAddNumber(double[] d1, double d2) throws Exception{
        if(d1.length <= 0){
            throw new Exception("Vector add number, empty vector not allowed!");
        }
        double[] d = new double[d1.length];
        for (int i = 0; i < d1.length; i++) {
            d[i] = d1[i] + d2;
        }
        return d;
    }

    public static double[] vecMinus(double[] d1, double[] d2) throws Exception{
        if(d1.length <= 0 || d2.length <= 0){
            throw new Exception("Vector minus, empty vector not allowed!");
        }else if (d1.length != d2.length){
            throw new Exception("Vector minus, dimension not matched!");
        }
        double[] d = new double[d1.length];
        for (int i = 0; i < d.length; i++) {
            d[i] = d1[i] - d2[i];
        }
        return d;
    }

    public static double norm(double[] d, double order){
        double r = 0;
        for (int i = 0; i < d.length; i++) {
            r += Math.pow(Math.abs(d[i]), order);
        }
        return Math.pow(r, 1.0/order);
    }

    public static double norm(KeyValuePair[] d, double order){
        double r = 0;
        for (int i = 0; i < d.length; i++) {
            r += Math.pow(Math.abs(d[i].value), order);
        }
        return Math.pow(r, 1.0/order);
    }

    public static double vecMultiply(double[] d1, double[] d2) throws Exception{
        if(d1.length <= 0 || d2.length <= 0){
            throw new Exception("Vector multiply, empty vector not allowed!");
        }else if (d1.length != d2.length){
            throw new Exception("Vector multiply, dimension not matched!");
        }
        double d = 0;
        for (int i = 0; i < d1.length; i++) {
            d += d1[i] * d2[i];
        }
        return d;
    }

    public static double[] vecMultiplyNumber(double[] d1, double d2) throws Exception{
        if(d1.length <= 0){
            throw new Exception("Vector multiply number, empty vector not allowed!");
        }
        double[] d = new double[d1.length];
        for (int i = 0; i < d1.length; i++) {
            d[i] = d1[i] * d2;
        }
        return d;
    }

    public static double vecMultiply(KeyValuePair[] d1, double[] d2) throws Exception{
        if(d1.length <= 0 || d2.length <= 0){
            throw new Exception("Vector multiply, empty vector not allowed!");
        }else if (d1[d1.length - 1].key >= d2.length){
            throw new Exception("Vector multiply, dimension not matched!");
        }
        double d = 0;
        for (int i = 0; i < d1.length; i++) {
            d += d1[i].value * d2[d1[i].key];
        }
        return d;
    }

    public static double[] concatenate(double[] d1, double[] d2){
        double[] d = new double[d1.length + d2.length];
        for(int i = 0; i < d1.length; i++){
            d[i] = d1[i];
        }
        for(int j = 0; j < d2.length; j++){
            d[j + d1.length] = d2[j];
        }
        return d;
    }

    public static double cosine(double[] d1, double[] d2) throws Exception{
        double n = norm(d1, 2) * norm(d2, 2);
        if(n <= 0.0){
            return 0;
        }
        return vecMultiply(d1, d2) / n;
    }

    public static double[] stretch(KeyValuePair[] d, int length){
        double[] v = new double[length];
        for (KeyValuePair kv : d){
            v[kv.key] = kv.value;
        }
        return v;
    }

    public static double[] stretch(KeyValuePair[] d){
        double[] v = new double[d.length];
        for (int i = 0; i < d.length; i++){
            v[d[i].key] = d[i].value;
        }
        return v;
    }

    public static double avg(KeyValuePair[] d, int length){
        return avg(stretch(d, length));
    }

    public static double avg(KeyValuePair[] d){
        return avg(stretch(d));
    }

    public static double avg(double[] d){
        if (d.length > 0) {
            return sum(d) / d.length;
        }
        return 0;
    }

    public static double sum(double[] d){
        double a = 0;
        for(int i = 0; i < d.length; i++){
            a += d[i];
        }
        return a;
    }

    public static int nnz(double[] d){
        int a = 0;
        for(int i = 0; i < d.length; i++){
            if (d[i] > 0) {
                a++;
            }
        }
        return a;
    }

    public static double stdError(double[] d){
        double e = 0;
        double a = avg(d);
        for (int i = 0; i < d.length; i++) {
            e += (d[i] - a) * (d[i] - a);
        }
        return Math.sqrt(e/d.length);
    }

    public static double stdError(KeyValuePair[] d, int length){
        return stdError(stretch(d, length));
    }

    public static double stdError(KeyValuePair[] d){
        return stdError(stretch(d));
    }

    public static int maxId(double[] d){
        int id = 0;
        for(int i = 1; i < d.length; i++){
            if (d[i] > d[id]){
                id = i;
            }
        }
        return id;
    }

    public static double maxValue(double[] d){
        return d[maxId(d)];
    }

    public static int minId(double[] d){
        int id = 0;
        for(int i = 1; i < d.length; i++){
            if (d[i] < d[id]){
                id = i;
            }
        }
        return id;
    }

    public static double minValue(double[] d){
        return d[minId(d)];
    }

    public static KeyValuePair[] hadamardMultiply(KeyValuePair[] a, KeyValuePair[] b){
        ArrayList<KeyValuePair> list = new ArrayList<>();
        int i = 0;
        int j = 0;
        while (i < a.length && j < b.length){
            if (a[i].key < b[j].key){
                i++;
            }else if(a[i].key > b[j].key){
                j++;
            }else{
                list.add(new KeyValuePair(a[i].key, a[i].value * b[j].value));
            }
        }
        return (KeyValuePair[])list.toArray();
    }

    //Matrix functions

    public static DenseMatrix arccos(DenseMatrix A) throws Exception{
        DenseMatrix B = new DenseMatrix(A.iNumOfRow, A.iNumOfColumn, 0);
        for (int i = 0; i < A.iNumOfRow; i++) {
            for (int j = 0; j < A.iNumOfColumn; j++) {
                B.set(i, j, Math.acos(A.get(i, j)));
            }
        }
        return B;
    }

    public static ArrayList<KeyValuePair> topK(ArrayList<KeyValuePair> list, int k) throws Exception{
        return topK(list, 0, k);
    }

    public static ArrayList<KeyValuePair> topK(ArrayList<KeyValuePair> list, int k1, int k2) throws Exception{
        ArrayList<KeyValuePair> rst = new ArrayList<>();
        for (int i = 0; i < list.size(); i++){
            insert(rst, list.get(i), k2);
        }
        for (int i = 0; i < k1; i++){
            rst.remove(0);
        }
        return rst;
//        return (ArrayList<KeyValuePair>)rst.subList(k1, k2);
    }

    public static void insert(ArrayList<KeyValuePair> list, KeyValuePair kv, int k) throws Exception{
        if(k <= 0){
            throw new Exception("k must be greater than 0!!!");
        }
        int locate = -1;
        for (int i = 0; i < list.size(); i++){
            if (list.get(i).value < kv.value){
                locate = i;
                break;
            }
        }
        if (locate < 0 && list.size() < k){
            list.add(kv);
        }else if (locate >= 0){
            list.add(locate, kv);
        }
        while (list.size() > k){
            list.remove(list.size() - 1);
        }
    }

    public static DenseMatrix rowExpansion(double[] diagonal, int nRow) throws Exception{
        DenseMatrix D = new DenseMatrix(nRow, diagonal.length, 0);
        for (int r = 0; r < D.iNumOfRow; r++){
            for (int c = 0; c < D.iNumOfColumn; c++){
                D.set(r, c, diagonal[c]);
            }
        }
        return D;
    }

    public static void log(RowSparseMatrix M) throws Exception{
        for (int r = 0; r < M.iNumOfRow; r++){
            for (int j = 0; j < M.pData[r].length; j++) {
                M.pData[r][j].value = log(M.pData[r][j].value + 1);
            }
        }
    }
}
