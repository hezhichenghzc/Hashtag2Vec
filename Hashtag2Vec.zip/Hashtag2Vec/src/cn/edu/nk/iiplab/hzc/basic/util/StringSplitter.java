/**
 * This project is developed by the Intelligent Information Processing Lab, Nankai University, Tianjin, China. (http://dm.nankai.edu.cn/)
 * It follows the GPLv3 license. Feel free to use it for non-commercial purpose and please cite our paper:
 * @inproceedings{Hashtag2Vec,
 *   author    = {Jie Liu and Zhicheng He and Yalou Huang},
 *   title     = {Hashtag2Vec: Learning Hashtag Representation with Relational Hierarchical Embedding Model},
 *   booktitle = {Proceedings of the Twenty-Seventh International Joint Conference on Artificial Intelligence, {IJCAI} 2018, July 13-19, 2018, Stockholm, Sweden.},
 *   pages     = {3456--3462},
 *   year      = {2018},
 *   doi       = {10.24963/ijcai.2018/480},
 *   }
 * Contact: jliu@nankai.edu.cn, hezhicheng@mail.nankai.edu.cn
 */
package cn.edu.nk.iiplab.hzc.basic.util;

import java.util.ArrayList;
import java.util.List;

public class StringSplitter {
    /**
     *
     * @param separator
     * @param original
     * @return a string[] generated from string original
     * by split it with all characters in string separator
     */
    public static String[] split(String separator, String original){
        char[] separator_char = separator.toCharArray();
        for(int i=1; i<separator_char.length; i++){
            original = original.replace(separator_char[i], separator_char[0]);
        }
        return original.split(separator.substring(0, 1));
    }
    /**
     *
     * @param original
     * @return original with all empty string deleted
     */
    public static String[] RemoveEmptyEntries(String[] original){
        int len = original.length;
        List<String> list = new ArrayList<String>(len);
        for(int i=0; i<len; i++){
            if(original[i] != null && !original[i].equals("")){
                list.add(original[i]);
            }
        }
        String[] result = new String[list.size()];
        for(int i=0; i<list.size(); i++){
            result[i] = list.get(i);
        }
        return result;
    }
}
