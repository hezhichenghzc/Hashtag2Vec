/**
 * This project is developed by the Intelligent Information Processing Lab, Nankai University, Tianjin, China. (http://dm.nankai.edu.cn/)
 * It follows the GPLv3 license. Feel free to use it for non-commercial purpose and please cite our paper:
 * @inproceedings{Hashtag2Vec,
 *   author    = {Jie Liu and Zhicheng He and Yalou Huang},
 *   title     = {Hashtag2Vec: Learning Hashtag Representation with Relational Hierarchical Embedding Model},
 *   booktitle = {Proceedings of the Twenty-Seventh International Joint Conference on Artificial Intelligence, {IJCAI} 2018, July 13-19, 2018, Stockholm, Sweden.},
 *   pages     = {3456--3462},
 *   year      = {2018},
 *   doi       = {10.24963/ijcai.2018/480},
 *   }
 * Contact: jliu@nankai.edu.cn, hezhicheng@mail.nankai.edu.cn
 */
package cn.edu.nk.iiplab.hzc.cluster.evaluation;

import cn.edu.nk.iiplab.hzc.basic.matrix.DenseMatrix;
import cn.edu.nk.iiplab.hzc.cluster.HungarianAlgorithm;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;

public class Evaluator {
    public static double epsilon = 1e-12;

    public static void main(String[] args) throws Exception {
        String matrix = "E:/hezhicheng/adnmf_output/????/20newsgroup/adnmf_init_fn/V.";
        String label = "E:/hezhicheng/data/20newsgroup/label1.txt";
        for (int i = 5; i <= 100; i += 5) {
            Evaluator eva = new Evaluator();
            DenseMatrix V = eva.loadClusterMatrix(matrix + i);
//            DenseMatrix nV = Functions.normalize(V, 1);

            ArrayList<Integer> clusterResult = eva.cluster(V);
            ArrayList<String> labels = eva.loadLabels(label);
            ArrayList<String> predictLabel = eva.predictLabel(clusterResult, labels);
            double acc = eva.accuracy(labels, predictLabel);
            System.out.println(i + " " + acc);
        }
    }

    //?????????????
    public DenseMatrix loadClusterMatrix(String input) throws Exception {
        BufferedReader br = new BufferedReader(new FileReader(input));
        String line = br.readLine();
        br.close();
        String[] content = line.split(";");
        int NumOfTerms = Integer.parseInt(content[0].split(":")[1]);
        int NumOfTopics = Integer.parseInt(content[1].split(":")[1]);

        DenseMatrix V = new DenseMatrix();
        V.load(input, NumOfTerms, NumOfTopics);
        return V;
    }

    //??????????????????
    public ArrayList<Integer> cluster(DenseMatrix matrix) throws Exception {
        ArrayList<Integer> result = new ArrayList<Integer>();
        for (int i = 0; i < matrix.iNumOfRow; i++) {
            int label = 0;
            double weight = matrix.get(i, 0);
            for (int j = 1; j < matrix.iNumOfColumn; j++) {
                if (matrix.get(i, j) > weight) {
                    weight = matrix.get(i, j);
                    label = j;
                }
            }
            result.add(label);
        }
        return result;
    }

    //????????????
    public ArrayList<String> loadLabels(String input) throws Exception {
        ArrayList<String> result = new ArrayList<String>();
        BufferedReader br = new BufferedReader(new FileReader(input));
        String line = null;
        while ((line = br.readLine()) != null) {
            result.add(line);
        }
        br.close();
        return result;
    }

    public ArrayList<Integer> loadLabelsInt(String input) throws Exception {
        ArrayList<Integer> result = new ArrayList<Integer>();
        BufferedReader br = new BufferedReader(new FileReader(input));
        String line = null;
        while ((line = br.readLine()) != null) {
            result.add(Integer.parseInt(line));
        }
        br.close();
        return result;
    }

    //?????????????????????????????????????????
    public HashMap<Integer, String> clusterLabels(ArrayList<Integer> clusterResult, ArrayList<String> originalLabel) {
        HashMap<Integer, HashMap<String, Integer>> cluster_label_count = new HashMap<Integer, HashMap<String, Integer>>();
        for (int i = 0; i < clusterResult.size(); i++) {
            int cluster = clusterResult.get(i);
            String label = originalLabel.get(i);
            if (cluster_label_count.containsKey(cluster)) {
                HashMap<String, Integer> label_count = cluster_label_count.get(cluster);
                if (label_count.containsKey(label)) {
                    label_count.put(label, label_count.get(label) + 1);
                } else {
                    label_count.put(label, 1);
                }
                cluster_label_count.put(cluster, label_count);
            } else {
                HashMap<String, Integer> label_count = new HashMap<String, Integer>();
                label_count.put(label, 1);
                cluster_label_count.put(cluster, label_count);
            }
        }
        HashMap<Integer, String> cluster_label = new HashMap<Integer, String>();
        Set<Integer> keys = cluster_label_count.keySet();
        for (int k : keys) {
            HashMap<String, Integer> label_count = cluster_label_count.get(k);
            Set<String> labels = label_count.keySet();
            String label = "unKnown";
            int count = -1;
            for (String l : labels) {
                if (label_count.get(l) > count) {
                    label = l;
                    count = label_count.get(l);
                }
            }
            cluster_label.put(k, label);
        }

        return cluster_label;
    }

    public HashMap<Integer, String> clusterLabelsHG(ArrayList<Integer> clusterResult, ArrayList<String> originalLabel) {
        ArrayList<Integer> cSet = new ArrayList<>();
        for(int c : clusterResult){
            if(!cSet.contains(c)){
                cSet.add(c);
            }
        }

        ArrayList<String> lSet = new ArrayList<>();
        for(String l : originalLabel){
            if(!lSet.contains(l)){
                lSet.add(l);
            }
        }

        HashMap<Integer, HashMap<String, Integer>> cluster_label_count = new HashMap<Integer, HashMap<String, Integer>>();
        for (int i = 0; i < clusterResult.size(); i++) {
            int cluster = clusterResult.get(i);
            String label = originalLabel.get(i);
            if (cluster_label_count.containsKey(cluster)) {
                HashMap<String, Integer> label_count = cluster_label_count.get(cluster);
                if (label_count.containsKey(label)) {
                    label_count.put(label, label_count.get(label) + 1);
                } else {
                    label_count.put(label, 1);
                }
                cluster_label_count.put(cluster, label_count);
            } else {
                HashMap<String, Integer> label_count = new HashMap<String, Integer>();
                label_count.put(label, 1);
                cluster_label_count.put(cluster, label_count);
            }
        }

        double[][] gain = new double[cSet.size()][lSet.size()];

        for (int k : cluster_label_count.keySet()) {
            int row = cSet.indexOf(k);
            for (String l : cluster_label_count.get(k).keySet()) {
                int col = lSet.indexOf(l);
                gain[row][col] += 1;
            }
        }
        int[][] assign = HungarianAlgorithm.hgAlgorithmAssignments(gain, "max");
        HashMap<Integer, String> cluster_label = new HashMap<Integer, String>();
        for(int i = 0; i < assign.length; i++){
            cluster_label.put(cSet.get(assign[i][0]), lSet.get(assign[i][1]));
        }
        return cluster_label;
    }

    //???????????????????????
    public ArrayList<String> predictLabel(ArrayList<Integer> clusterResult, ArrayList<String> originalLabel) {
        HashMap<Integer, String> cluster_label = clusterLabels(clusterResult, originalLabel);

        ArrayList<String> predictedLabel = new ArrayList<String>();
        for (int i = 0; i < clusterResult.size(); i++) {
            predictedLabel.add(cluster_label.get(clusterResult.get(i)));
        }
        return predictedLabel;
    }

    public ArrayList<String> predictLabelHG(ArrayList<Integer> clusterResult, ArrayList<String> originalLabel) {
        HashMap<Integer, String> cluster_label = clusterLabelsHG(clusterResult, originalLabel);

        ArrayList<String> predictedLabel = new ArrayList<String>();
        for (int i = 0; i < clusterResult.size(); i++) {
            predictedLabel.add(cluster_label.get(clusterResult.get(i)));
        }
        return predictedLabel;
    }

    //????
    public double accuracy(ArrayList<String> originalLabel, ArrayList<String> predictedLabel) {
        double count = 0;
        for (int i = 0; i < originalLabel.size(); i++) {
            if (originalLabel.get(i).equals(predictedLabel.get(i))) {
                count++;
            }
        }
        return count / (double) originalLabel.size();
    }

    //??????i??0~C??????????j??0~C???????
    public double[][] crossProbability(ArrayList<String> originalLabel, ArrayList<String> predictedLabel) {
        //??????????
        ArrayList<String> labels = new ArrayList<String>();
        for (int i = 0; i < originalLabel.size(); i++) {
            if (!labels.contains(originalLabel.get(i))) {
                labels.add(originalLabel.get(i));
            }
        }
        double[][] p = new double[labels.size()][labels.size()];
        for (int i = 0; i < originalLabel.size(); i++) {
            String ol = originalLabel.get(i);
            String pl = predictedLabel.get(i);
            p[labels.indexOf(ol)][labels.indexOf(pl)] += 1.0 / (double) originalLabel.size();
        }
        return p;
    }

    //Shannon Entropy
    public double entropy(double[] p) {
        double h = 0;
        for (int i = 0; i < p.length; i++) {
            h -= (p[i] + epsilon) * Math.log(p[i] + epsilon) / Math.log(2);
        }
        return h;
    }

    //???????????
    public double normalizedMutualInformation(double[][] p) {
        int clusterNum = p.length;
        double[] originalP = new double[clusterNum];
        double[] predictedP = new double[clusterNum];
        for (int i = 0; i < clusterNum; i++) {
            for (int j = 0; j < clusterNum; j++) {
                originalP[i] += p[i][j];
                predictedP[j] += p[i][j];
            }
        }
        double h = Math.max(entropy(originalP), entropy(predictedP));
//		System.out.println("h: " + h);
        double mi = 0;
        for (int i = 0; i < clusterNum; i++) {
            for (int j = 0; j < clusterNum; j++) {
                mi += (p[i][j] + epsilon) * Math.log((p[i][j] + epsilon) / (originalP[i] * predictedP[j] + epsilon)) / Math.log(2);
            }
        }
        return mi / h;
    }

    //Jaccard?????
    public double jaccardSimilarity(ArrayList<String> originalLabel, ArrayList<String> predictedLabel) {
        //??????????
        ArrayList<String> labels = new ArrayList<String>();
        for (int i = 0; i < originalLabel.size(); i++) {
            if (!labels.contains(originalLabel.get(i))) {
                labels.add(originalLabel.get(i));
            }
        }
        double jaccard = 0;
        for (String label : labels) {
            HashSet<Integer> oSet = new HashSet<Integer>();
            HashSet<Integer> pSet = new HashSet<Integer>();
            for (int i = 0; i < originalLabel.size(); i++) {
                if (originalLabel.get(i).equals(label)) {
                    oSet.add(i);
                }
                if (predictedLabel.get(i).equals(label)) {
                    pSet.add(i);
                }
            }
            jaccard += jaccardCoefficient(oSet, pSet);
        }
        return jaccard / labels.size();
    }

    //Jaccard?????J(A,B)=|A intersect B| / |A union B|
    public double jaccardCoefficient(HashSet<Integer> A, HashSet<Integer> B) {
        if (A.size() * B.size() == 0) {
            return 0;
        }
        double intersect = 0;
        for (Integer a : A) {
            for (Integer b : B) {
                if (a == b) {
                    intersect += 1;
                }
            }
        }
        return intersect / (A.size() + B.size() - intersect);
    }

    public double evaluate(String clusterInput, String labelInput, String metric) throws Exception {
        DenseMatrix V = loadClusterMatrix(clusterInput);
        ArrayList<Integer> clusterResult = cluster(V);
        ArrayList<String> labels = loadLabels(labelInput);

        ArrayList<String> predictLabel = predictLabel(clusterResult, labels);
        if (metric.equalsIgnoreCase("accuracy")) {
            return accuracy(labels, predictLabel);
        } else if (metric.equalsIgnoreCase("nmi")) {
            double[][] p = crossProbability(labels, predictLabel);
            return normalizedMutualInformation(p);
        } else {
            return jaccardSimilarity(labels, predictLabel);
        }
    }

    public HashMap<Integer, HashMap<String, Integer>> spectrum(String clusterInput, String labelInput) throws Exception {
        DenseMatrix V = loadClusterMatrix(clusterInput);
        ArrayList<Integer> clusterResult = cluster(V);
        ArrayList<String> labels = loadLabels(labelInput);

        HashMap<Integer, HashMap<String, Integer>> cluster_label_count = new HashMap<Integer, HashMap<String, Integer>>();
        for (int i = 0; i < clusterResult.size(); i++) {
            int cluster = clusterResult.get(i);
            String label = labels.get(i);
            if (cluster_label_count.containsKey(cluster)) {
                HashMap<String, Integer> label_count = cluster_label_count.get(cluster);
                if (label_count.containsKey(label)) {
                    label_count.put(label, label_count.get(label) + 1);
                } else {
                    label_count.put(label, 1);
                }
                cluster_label_count.put(cluster, label_count);
            } else {
                HashMap<String, Integer> label_count = new HashMap<String, Integer>();
                label_count.put(label, 1);
                cluster_label_count.put(cluster, label_count);
            }
        }
        return cluster_label_count;
    }

    public double evaluateHG(String clusterInput, String labelInput, String metric) throws Exception {
        DenseMatrix V = loadClusterMatrix(clusterInput);
        ArrayList<Integer> clusterResult = cluster(V);
        ArrayList<String> labels = loadLabels(labelInput);

        ArrayList<String> predictLabel = predictLabelHG(clusterResult, labels);
        if (metric.equalsIgnoreCase("accuracy")) {
            return accuracy(labels, predictLabel);
        } else if (metric.equalsIgnoreCase("nmi")) {
            double[][] p = crossProbability(labels, predictLabel);
            return normalizedMutualInformation(p);
        } else {
            return jaccardSimilarity(labels, predictLabel);
        }
    }

    public double evaluateLab(String preLab, String labelInput, String metric) throws Exception {
        ArrayList<Integer> clusterResult = loadLabelsInt(preLab);
        ArrayList<String> labels = loadLabels(labelInput);

        ArrayList<String> predictLabel = predictLabel(clusterResult, labels);
        if (metric.equalsIgnoreCase("accuracy")) {
            return accuracy(labels, predictLabel);
        } else if (metric.equalsIgnoreCase("nmi")) {
            double[][] p = crossProbability(labels, predictLabel);
            return normalizedMutualInformation(p);
        } else {
            return jaccardSimilarity(labels, predictLabel);
        }
    }
}
