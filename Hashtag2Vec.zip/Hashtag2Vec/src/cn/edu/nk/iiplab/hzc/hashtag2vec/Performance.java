/**
 * This project is developed by the Intelligent Information Processing Lab, Nankai University, Tianjin, China. (http://dm.nankai.edu.cn/)
 * It follows the GPLv3 license. Feel free to use it for non-commercial purpose and please cite our paper:
 * @inproceedings{Hashtag2Vec,
 *   author    = {Jie Liu and Zhicheng He and Yalou Huang},
 *   title     = {Hashtag2Vec: Learning Hashtag Representation with Relational Hierarchical Embedding Model},
 *   booktitle = {Proceedings of the Twenty-Seventh International Joint Conference on Artificial Intelligence, {IJCAI} 2018, July 13-19, 2018, Stockholm, Sweden.},
 *   pages     = {3456--3462},
 *   year      = {2018},
 *   doi       = {10.24963/ijcai.2018/480},
 *   }
 * Contact: jliu@nankai.edu.cn, hezhicheng@mail.nankai.edu.cn
 */
package cn.edu.nk.iiplab.hzc.hashtag2vec;

import cn.edu.nk.iiplab.hzc.basic.MF;
import cn.edu.nk.iiplab.hzc.basic.matrix.DenseMatrix;
import cn.edu.nk.iiplab.hzc.basic.matrix.RowSparseMatrix;

import cn.edu.nk.iiplab.hzc.basic.struct.KVPComparatorDsc;
import cn.edu.nk.iiplab.hzc.basic.struct.KeyValuePair;
import cn.edu.nk.iiplab.hzc.basic.util.Functions;
import weka.clusterers.ClusterEvaluation;
import weka.clusterers.SimpleKMeans;
import weka.core.Instances;
import weka.core.converters.ConverterUtils;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.*;

import cn.edu.nk.iiplab.hzc.cluster.evaluation.Evaluator;


public class Performance extends MF {

    public String data_path = "";
    public String logger_path = "";
    public Evaluator eva;

    public Performance(String data_path, String logger_path) {
        this.data_path = data_path;
        this.logger_path = logger_path;
        this.eva = new Evaluator();
    }

    public double[] evaluate(DenseMatrix W_h, DenseMatrix W_t, DenseMatrix W_w, RowSparseMatrix M_w_w, Logger logger,
                             String hashtag_cindices, String hashtag_labels, int hashtag_cluster_num,
                             String tweet_cindices, String tweet_labels, int tweet_cluster_num,
                             int[] pmi_top) throws Exception {

        double[] res = new double[9];
        // Evaluate hashtag embeddings
        int[] cindices = loadIntegerArray(data_path + hashtag_cindices); // Indices of the manually labeled hashtags
        int[] labels = loadIntegerArray(data_path + hashtag_labels); // Cluster labels of hashtags
        double[][] embeddings = new double[cindices.length][W_h.iNumOfColumn]; // Learned hashtag embeddings
        for (int i = 0; i < cindices.length; i++) {
            embeddings[i] = W_h.pData[cindices[i]];
        }

        double[] temp = kmeans_purity(embeddings, hashtag_cluster_num, logger, labels);
        res[0] = temp[0]; // Hashtag clustering purity
        res[1] = temp[1]; // Hashtag clustering nmi
        res[2] = hscore_nmi(embeddings, hashtag_cluster_num, labels); // Hashtag clustering h-score

        // Evaluate tweet embeddings
        cindices = loadIntegerArray(data_path + tweet_cindices); // Indices of the manually labeled tweets
        labels = loadIntegerArray(data_path + tweet_labels); // Cluster labels of tweets
        embeddings = new double[cindices.length][W_t.iNumOfColumn]; // Learned tweet embeddings
        for (int i = 0; i < cindices.length; i++) {
            embeddings[i] = W_t.pData[cindices[i]];
        }

        temp = kmeans_purity(embeddings, tweet_cluster_num, logger, labels);
        res[3] = temp[0]; // Tweet clustering purity
        res[4] = temp[1]; // Tweet clustering nmi
        res[5] = hscore_nmi(embeddings, tweet_cluster_num, labels); // Tweet clustering h-score

        // Evaluate word embeddings
        temp = pmi(M_w_w, W_w, pmi_top);
        for (int i = 0; i < temp.length; i++) {
            res[i + 6] = temp[i];
        }
        return res;
    }


    public double hscore_nmi(double[][] embeddings, int n_cluster, int[] y_gd) throws Exception {
        List<ArrayList<Integer>> clusters = new ArrayList<ArrayList<Integer>>();
        for (int i = 0; i < n_cluster; i++) {
            ArrayList<Integer> temp = new ArrayList<Integer>();
            clusters.add(temp);
        }
        for (int i = 0; i < y_gd.length; i++) {
            clusters.get(y_gd[i] - 1).add(i);
        }
        String temp = "cluster_numbers: ";
        for (int i = 0; i < n_cluster; i++) {
            temp += clusters.get(i).size() + " ";
        }
        System.out.println(temp);
        //logger.write(temp);
        double intraDis = 0;
        for (int i = 0; i < n_cluster; i++) {
            List<Integer> cluster = clusters.get(i);
            int len = cluster.size();
            double oneDis = 0;
            for (int j = 0; j < cluster.size(); j++) {
                for (int k = j + 1; k < cluster.size(); k++) {
                    oneDis += 1 - Functions.cosine(embeddings[cluster.get(j)], embeddings[cluster.get(k)]);
                }
            }
            oneDis = oneDis * 2 / (len * (len - 1));
            intraDis += oneDis;
        }
        intraDis = intraDis / n_cluster;
        double interDis = 0;
        for (int i = 0; i < n_cluster; i++) {
            for (int j = i + 1; j < n_cluster; j++) {
                List<Integer> cluster1 = clusters.get(i);
                List<Integer> cluster2 = clusters.get(j);
                int len1 = cluster1.size();
                int len2 = cluster2.size();
                double oneDis = 0;
                for (int k = 0; k < len1; k++) {
                    for (int l = 0; l < len2; l++) {
                        oneDis += 1 - Functions.cosine(embeddings[cluster1.get(k)], embeddings[cluster2.get(l)]);
                    }
                }
                oneDis = oneDis * 2 / (len1 * len2);
                interDis += oneDis;

            }
        }
        interDis = interDis / (n_cluster * (n_cluster - 1));
        return intraDis / interDis;
    }

    public double purity(int n_cluster, int[] y_pred, Logger logger, int[] labels, int sub1, int sub2) throws Exception {

        List<ArrayList<Integer>> clusters1 = getCommunities(y_pred, sub1, n_cluster);
        String temp = "cluster_numbers: ";
        for (int i = 0; i < n_cluster; i++) {
            temp += clusters1.get(i).size() + " ";
        }
        System.out.println(temp);
        logger.write(temp);
        List<ArrayList<Integer>> clusters2 = getCommunities(labels, sub2, n_cluster);
        int sumi = 0;
        for (int i = 0; i < clusters1.size(); i++) {
            int num_inter = -1;
            List<Integer> inter = new ArrayList<Integer>();
            for (int j = 0; j < clusters2.size(); j++) {
                inter = Inter(clusters1.get(i), clusters2.get(j));
                if (inter.size() > num_inter) {
                    num_inter = inter.size();
                }
            }
            sumi += num_inter;
        }
        double purity = (double) sumi / labels.length;
        return purity;
    }

    public double[] kmeans_purity(double[][] embeddings, int numofClusters, Logger logger, int[] assL) throws Exception {
        double[] res = new double[2];

        String wekaFile = logger_path + "weka.arff";
        getDataForWeka(embeddings, wekaFile);
        double[] ass = weka_kmeans(wekaFile, numofClusters);
        int[] assI = new int[ass.length];
        for (int i = 0; i < ass.length; i++) {
            assI[i] = (int) ass[i];
        }
        double purity = purity(numofClusters, assI, logger, assL, 0, 1);
        res[0] = purity;

        ArrayList<String> labels = new ArrayList<String>();
        for (int i = 0; i < assL.length; i++) {
            labels.add(String.valueOf(assL[i]));
        }
        ArrayList<String> predictLabel = new ArrayList<String>();
        for (int i = 0; i < assI.length; i++) {
            predictLabel.add(String.valueOf(assI[i] + 1));
        }
        double[][] p = eva.crossProbability(labels, predictLabel);
        double nmi = eva.normalizedMutualInformation(p);
        res[1] = nmi;
        return res;
    }

    public double[] weka_kmeans(String file_path, int numofClusters) throws Exception {
        Instances data = ConverterUtils.DataSource.read(file_path);
        SimpleKMeans sk = new SimpleKMeans();
        sk.setNumClusters(numofClusters);
        sk.buildClusterer(data);
        ClusterEvaluation eval = new ClusterEvaluation();
        eval.setClusterer(sk);
        eval.evaluateClusterer(new Instances(data));
        int classNum = eval.getNumClusters();
        double[] ass = eval.getClusterAssignments();
        System.out.println(ass.length);
        return ass;
    }

    public double[] pmi(RowSparseMatrix M_w_w, DenseMatrix W_w, int[] Ms) throws Exception {
        DenseMatrix dmt = W_w.transpose();
        List<List<KeyValuePair>> topics_eles = new ArrayList<>();
        for (int i = 0; i < dmt.iNumOfRow; i++) {
            double[] row = dmt.getRow(i);
            List<KeyValuePair> eles = new ArrayList<>();
            for (int j = 0; j < row.length; j++) {
                eles.add(new KeyValuePair(j, row[j]));
            }
            Collections.sort(eles, new KVPComparatorDsc());
            topics_eles.add(eles);
        }
        double ress[] = new double[Ms.length];
        for (int i = 0; i < Ms.length; i++) {
            int M = Ms[i];
            double res = 0;
            for (int j = 0; j < dmt.iNumOfRow; j++) {
                List<KeyValuePair> eles = topics_eles.get(j);
                double sum = 0;
                for (int k = 0; k < M; k++) {
                    int windex1 = eles.get(k).key;
                    for (int l = k + 1; l < M; l++) {
                        int windex2 = eles.get(l).key;
                        //double pmi=getPMI(windex1,windex2,M_w_w,M_sum);
                        double pmi = M_w_w.get(windex1, windex2);
                        //System.out.println(pmi);
                        sum += pmi;
                    }
                }
                //System.out.println("sum is :"+sum);
                sum = sum * 2 / (M * (M - 1));
                //System.out.println("sum is :"+sum);
                res += sum;
            }
            // T topic's average
            res = res / dmt.iNumOfRow;
            ress[i] = res;
        }

        return ress;
    }

    public int[] loadIntegerArray(String file_path) throws Exception {
        BufferedReader br = new BufferedReader(new FileReader(file_path));
        String line = br.readLine();
        int numOfLines = Integer.parseInt(line);
        int[] res = new int[numOfLines];
        int count = 0;
        while ((line = br.readLine()) != null) {
            int num = Integer.parseInt(line);
            res[count] = num;
            count++;
        }
        br.close();
        return res;
    }

    public void getDataForWeka(double[][] embeddings, String wekaFile) throws Exception {
        String outputFile = wekaFile;
        FileWriter fw = new FileWriter(outputFile);
        BufferedWriter bw = new BufferedWriter(fw);
        int numofInstances = embeddings.length;
        bw.write("@relation Product\n");
        for (int i = 1; i <= numofInstances; i++) {
            String temp = "@attribute " + i + " numeric\n";
            bw.write(temp);
        }
        bw.write("@data\n");
        for (int i = 0; i < numofInstances; i++) {
            for (int j = 0; j < numofInstances; j++) {
                double cos = Functions.cosine(embeddings[i], embeddings[j]);
                if (j < numofInstances - 1) {
                    bw.write(cos + ",");
                } else {
                    bw.write(cos + "\n");
                }
            }
        }
        bw.close();
        fw.close();

    }

    public List<Integer> Inter(List<Integer> a1, List<Integer> a2) {
        List<Integer> inter = new ArrayList<Integer>();
        for (int i = 0; i < a1.size(); i++) {
            if (a2.contains(a1.get(i))) {
                inter.add(a1.get(i));
            }
        }
        return inter;
    }

    public List<ArrayList<Integer>> getCommunities(int[] y_pred, int sub, int n_cluster) {
        List<ArrayList<Integer>> clusters = new ArrayList<ArrayList<Integer>>();
        for (int i = 0; i < n_cluster; i++) {
            ArrayList<Integer> temp = new ArrayList<Integer>();
            clusters.add(temp);
        }
        for (int i = 0; i < y_pred.length; i++) {
            clusters.get(y_pred[i] - sub).add(i);
        }
        return clusters;
    }
}
