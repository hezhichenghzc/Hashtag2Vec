/**
 * This project is developed by the Intelligent Information Processing Lab, Nankai University, Tianjin, China. (http://dm.nankai.edu.cn/)
 * It follows the GPLv3 license. Feel free to use it for non-commercial purpose and please cite our paper:
 * @inproceedings{Hashtag2Vec,
 *   author    = {Jie Liu and Zhicheng He and Yalou Huang},
 *   title     = {Hashtag2Vec: Learning Hashtag Representation with Relational Hierarchical Embedding Model},
 *   booktitle = {Proceedings of the Twenty-Seventh International Joint Conference on Artificial Intelligence, {IJCAI} 2018, July 13-19, 2018, Stockholm, Sweden.},
 *   pages     = {3456--3462},
 *   year      = {2018},
 *   doi       = {10.24963/ijcai.2018/480},
 *   }
 * Contact: jliu@nankai.edu.cn, hezhicheng@mail.nankai.edu.cn
 */
package cn.edu.nk.iiplab.hzc.basic.matrix;

import cn.edu.nk.iiplab.hzc.basic.util.Functions;
import cn.edu.nk.iiplab.hzc.basic.util.StringSplitter;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Random;
import java.util.ArrayList;
import cn.edu.nk.iiplab.hzc.basic.struct.KeyValuePair;

public class DenseMatrix implements Cloneable {
    public double[][] pData;
    public int iNumOfRow;
    public int iNumOfColumn;

    /**
     * constructs an empty DenseMatrix
     */
    public DenseMatrix() {}

    /**
     * constructs a DenseMatrix with specified number of rows and columns, and entry values
     *
     * @param row number of rows
     * @param col number of columns
     */
    public DenseMatrix(int row, int col, double value) {
        pData = new double[row][];
        for (int i = 0; i < row; i++) {
            pData[i] = new double[col];
            for (int j = 0; j < col; j++) {
                pData[i][j] = value;
            }
        }
        iNumOfColumn = col;
        iNumOfRow = row;
    }

    /**
     * get method for matrix entry
     *
     * @param row row number
     * @param col column number
     * @return the specified matrix entry
     * @throws Exception if out of index bound
     */
    public double get(int row, int col) throws Exception {
        if (row >= iNumOfRow || col >= iNumOfColumn || pData == null) {
            throw new Exception("out of index bound");
        }
        return pData[row][col];
    }

    public double[] getRow(int row) throws Exception {
        if (row >= iNumOfRow || pData == null) {
            throw new Exception("out of index bound");
        }
        return pData[row];
    }

    public double[] getColumn(int col) throws Exception {
        if (col >= iNumOfColumn || pData == null) {
            throw new Exception("out of index bound");
        }
        double[] d = new double[iNumOfRow];
        for (int i = 0; i < iNumOfRow; i++) {
            d[i] = pData[i][col];
        }
        return d;
    }

    /**
     * set method for matrix entry
     *
     * @param row   row number
     * @param col   column number
     * @param value new value for the matrix entry
     * @return succeed or not
     * @throws Exception if out of index bound
     */
    public void set(int row, int col, double value) throws Exception {
        if (row >= iNumOfRow || col >= iNumOfColumn || pData == null) {
        	throw new Exception("out of index bound");
        }
        pData[row][col] = value;
    }

    /**
     * Matrix Inversion Using Cholesky decomposition
     */
    public void inverse() throws Exception {
        // do Cholesky decomposition
        if (iNumOfRow != iNumOfColumn || iNumOfColumn <= 0 || pData == null) {
            throw new Exception("cannot conduct inverse");
        }
        int dim = iNumOfRow;
        for (int i = 0; i < dim; i++) {
            for (int j = 0; j < dim; j++) {
                if (j == i) {
                    double sum = 0;
                    for (int k = 0; k < i; k++) {
                        sum += pData[i][k] * pData[i][k];
                    }
                    if ((pData[i][i] - sum) <= 0) {
                        throw new Exception("Negative x_ii - sum");
                    } else {
                        pData[i][i] = Math
                                .sqrt(pData[i][i] - sum);
                    }
                } else {
                    double sum = 0;
                    for (int k = 0; k < i; k++) {
                        sum += pData[j][k] * pData[i][k];
                    }
                    pData[j][i] = (pData[j][i] - sum)
                            / pData[i][i];
                }
            }
        }

        // calculate the inverse matrix of the upper-triangular matrix
        double[][] Cho_matrix_Inv = new double[dim][dim];
        for (int i = 0; i < dim; i++) {
            for (int j = 0; j < dim; j++) {
                if (j == i) {
                    Cho_matrix_Inv[j][i] = 1 / pData[j][i];
                } else {
                    double sum = 0;
                    for (int k = i; k < j; k++) {
                        sum += pData[j][k] * Cho_matrix_Inv[k][i];
                    }
                    Cho_matrix_Inv[j][i] = (-sum / pData[j][j]);
                }
            }
        }

        // calcuale the inverse matrix
        double[] temp = new double[dim];
        for (int i = 0; i < dim; i++) {
            for (int k = 0; k < dim; k++) {
                temp[k] = 0.0F;
            }
            for (int j = 0; j < dim; j++) {
                if (i <= j) {
                    double sum = 0;
                    for (int k = j; k < dim; k++) {
                        sum += Cho_matrix_Inv[k][i] * Cho_matrix_Inv[k][j];
                    }
                    temp[j] = sum;
                } else {
                    temp[j] = pData[j][i];
                }
            }
            for (int j = 0; j < dim; j++) {
                pData[i][j] = temp[j];
            }
        }
    }

    /**
     * load matrix entries from file or generate random ones
     *
     * @param path  file path
     * @param iRows number of rows when generate random entries
     * @param iCols number of columns when generate random entries
     * @return succeed or not
     * @throws Exception if file reading fails
     */
    public boolean load(String path, int iRows, int iCols) throws Exception {
        iNumOfRow = iRows;
        iNumOfColumn = iCols;
        if (path == null || path.equals("") || !new File(path).exists()) {
            System.out.println("input file: " + path + " not found!!!");
            return false;
        }
        BufferedReader br = new BufferedReader(new FileReader(path));
        br.readLine(); // the first line

        pData = new double[iNumOfRow][];
        int cnt = -1;
        String line;
        while ((line = br.readLine()) != null) {
            String[] tokens = StringSplitter.RemoveEmptyEntries(StringSplitter.split("\t ", line));
            cnt++;
            if (cnt < 0 || cnt >= iNumOfRow) {
                br.close();
                throw new Exception("row index out of range");
            }
            pData[cnt] = new double[iNumOfColumn];
            for (int i = 1; i < tokens.length; i++) {
                String tok[] = tokens[i].split(":");
                int iColumnID = Integer.parseInt(tok[0]);
                if (iColumnID < 0 || iColumnID >= iNumOfColumn) {
                    br.close();
                    throw new Exception("column index out of range");
                }
                pData[cnt][iColumnID] = Double.parseDouble(tok[1]);
            }
        }
        br.close();
        System.out.println( iNumOfRow + " rows and " + iNumOfColumn + " columns are loaded from " + path);
        return true;
    }

    public boolean save(String path) throws IOException{
    	BufferedWriter bw=new BufferedWriter(new FileWriter(path));
    	for(int i=0;i<iNumOfRow;i++){
    		for(int j=0;j<iNumOfColumn;j++){
    			if(j<iNumOfColumn-1)
    				bw.write(pData[i][j]+" ");
    			else
    				bw.write(pData[i][j]+"\n");
    		}
    	}
    	bw.close();
    	return true;
    }
    
    
    public boolean loadRaw(String path, int iRows, int iCols) throws Exception {
        iNumOfRow = iRows;
        iNumOfColumn = iCols;
        if (path == null || path.equals("") || !new File(path).exists()) {
            System.out.println("input file: " + path + " not found!!!");
            return false;
        }
        BufferedReader br = new BufferedReader(new FileReader(path));

        pData = new double[iNumOfRow][];
        int cnt = -1;
        String line;
        while ((line = br.readLine()) != null) {
            String[] tokens = StringSplitter.RemoveEmptyEntries(StringSplitter.split("\t ", line));
            cnt++;
            if (cnt < 0 || cnt >= iNumOfRow) {
                br.close();
                throw new Exception("row index out of range");
            }
            pData[cnt] = new double[iNumOfColumn];
            for (int i = 0; i < tokens.length; i++) {
                if (i >= iNumOfColumn) {
                    br.close();
                    throw new Exception("column index out of range");
                }
                pData[cnt][i] = Double.parseDouble(tokens[i]);
            }
        }
        br.close();
        System.out.println( iNumOfRow + " rows and " + iNumOfColumn + " columns are loaded from " + path);
        return true;
    }

    public void randInit(int iRows, int iCols){
        iNumOfRow = iRows;
        iNumOfColumn = iCols;
        Random rd = new Random(System.currentTimeMillis());
        pData = new double[iNumOfRow][];
        for (int i = 0; i < iNumOfRow; i++) {
            pData[i] = new double[iNumOfColumn];
            for (int j = 0; j < iNumOfColumn; j++) {
                pData[i][j] = rd.nextDouble();
            }
        }
        System.out.println("\n" + iNumOfRow + " rows and " + iNumOfColumn + " columns are randomly generated");
    }
    /**
     * Release all of the memory
     */
    public void releaseMemory() {
        pData = null;
        iNumOfRow = 0;
        iNumOfColumn = 0;
    }

    /**
     * set all of the entries zero
     */
    public void zero() throws Exception {
        if (iNumOfRow == 0 || iNumOfColumn == 0 || pData == null) {
            throw new Exception("cannot zero empty matrix");
        }
        for (int i = 0; i < iNumOfRow; i++) {
            for (int j = 0; j < iNumOfColumn; j++) {
                pData[i][j] = 0.0;
            }
        }
    }

    @Override
    protected Object clone() throws CloneNotSupportedException {
        DenseMatrix dup = new DenseMatrix();
        dup.iNumOfRow = this.iNumOfRow;
        dup.iNumOfColumn = this.iNumOfColumn;
        dup.pData = new double[dup.iNumOfRow][dup.iNumOfColumn];
        for (int i = 0; i < this.pData.length; i++) {
            for (int j = 0; j < this.pData[i].length; j++) {
                dup.pData[i][j] = this.pData[i][j];
            }
        }
        return dup;
    }

    public DenseMatrix copy() throws CloneNotSupportedException {
        return (DenseMatrix) this.clone();
    }

    public DenseMatrix transpose() {
        DenseMatrix trans = new DenseMatrix();
        trans.iNumOfRow = this.iNumOfColumn;
        trans.iNumOfColumn = this.iNumOfRow;
        trans.pData = new double[trans.iNumOfRow][trans.iNumOfColumn];
        for (int i = 0; i < this.pData.length; i++) {
            for (int j = 0; j < this.pData[i].length; j++) {
                trans.pData[j][i] = this.pData[i][j];
            }
        }
        return trans;
    }

    public DenseMatrix normalizeByRow(double order) throws Exception{
        DenseMatrix Result = new DenseMatrix(iNumOfRow, iNumOfColumn, 0);
        for(int iRow = 0; iRow < iNumOfRow; iRow++){
            double norm = Functions.norm(this.getRow(iRow), order);
            for(int iCol = 0; iCol < iNumOfColumn; iCol++){
                Result.set(iRow, iCol, this.get(iRow, iCol) / Math.max(norm, Functions.epsilon));
            }
        }
        return Result;
    }

    public DenseMatrix normalizeByColumn(double order) throws Exception{
        DenseMatrix Result = new DenseMatrix(iNumOfRow, iNumOfColumn, 0);
        for(int iCol = 0; iCol < iNumOfColumn; iCol++){
            double norm = Functions.norm(this.getColumn(iCol), order);
            for(int iRow = 0; iRow < iNumOfRow; iRow++){
                Result.set(iRow, iCol, this.get(iRow, iCol) / Math.max(norm, Functions.epsilon));
            }
        }
        return Result;
    }

    public RowSparseMatrix toRowSparseMatrix() throws Exception{
        RowSparseMatrix Result = new RowSparseMatrix();
        Result.iNumOfRow = iNumOfRow;
        Result.iNumOfColumn = iNumOfColumn;
        Result.pData = new KeyValuePair[iNumOfRow][];
        for (int iRow = 0; iRow < iNumOfRow; iRow++){
            ArrayList<Integer> kList = new ArrayList<>();
            for (int iCol = 0; iCol < iNumOfColumn; iCol++){
                if (pData[iRow][iCol] != 0){
                    kList.add(iCol);
                }
            }
            Result.pData[iRow] = new KeyValuePair[kList.size()];
            for (int i = 0; i < kList.size(); i++){
                Result.pData[iRow][i] = new KeyValuePair(kList.get(i), pData[iRow][kList.get(i)]);
            }
        }
        return Result;
    }

    public void show(){
        for(int i=0;i<8;i++){
            for(int j=0;j<iNumOfColumn;j++){
                if(j<iNumOfColumn-1)
                    System.out.print(pData[i][j]+" ");
                else
                    System.out.print(pData[i][j]+"\n");
            }
        }
    }
}
